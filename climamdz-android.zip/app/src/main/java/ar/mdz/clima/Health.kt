package ar.mdz.clima

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Salud de la vigilancia: ¿el servicio está vivo?, ¿hay internet?, ¿la última revisión pudo bajar datos?
 * Lo usa el servicio (cada ~5 min), la pantalla de Avisos y el aviso "sin conexión".
 */
object Health {
    const val NOTIF_ID = 2
    /** Cantidad de revisiones seguidas sin datos (≈15 min) a partir de la cual se avisa. */
    const val FAILS_TO_WARN = 3

    private val PING_URLS = listOf(
        "https://api.open-meteo.com/v1/forecast?latitude=-32.89&longitude=-68.85&current=temperature_2m",
        "https://api.met.no/weatherapi/locationforecast/2.0/status"
    )

    fun hasNet(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val n = cm.activeNetwork ?: return false
            val c = cm.getNetworkCapabilities(n) ?: return false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            false
        }
    }

    fun recordOk(ctx: Context) {
        Store.p(ctx).edit()
            .putLong("last_ok", System.currentTimeMillis())
            .putLong("last_try", System.currentTimeMillis())
            .putInt("fails", 0)
            .apply()
        clearOutage(ctx)
    }

    /** Anota una revisión fallida; si ya van varias seguidas, avisa. Devuelve la cantidad de fallas seguidas. */
    fun recordFail(ctx: Context, warn: Boolean = true): Int {
        val p = Store.p(ctx)
        val n = p.getInt("fails", 0) + 1
        p.edit().putLong("last_try", System.currentTimeMillis()).putInt("fails", n).apply()
        if (warn && n >= FAILS_TO_WARN) notifyOutage(ctx)
        return n
    }

    fun recordNext(ctx: Context, at: Long) {
        Store.p(ctx).edit().putLong("next_at", at).apply()
    }

    fun json(ctx: Context): String {
        val p = Store.p(ctx)
        val o = JSONObject()
        o.put("service", MonitorService.instance != null)
        o.put("net", hasNet(ctx))
        o.put("lastOk", p.getLong("last_ok", 0L))
        o.put("lastTry", p.getLong("last_try", 0L))
        o.put("fails", p.getInt("fails", 0))
        o.put("nextAt", p.getLong("next_at", 0L))
        o.put("ringing", Alarm.isRinging())
        o.put("testFired", p.getLong("test_fired", 0L))
        o.put("now", System.currentTimeMillis())
        return o.toString()
    }

    /** Prueba real: baja un dato de la fuente de clima. Bloquea: llamar desde un hilo aparte. */
    fun ping(): Pair<Boolean, Long> {
        val t0 = SystemClock.elapsedRealtime()
        for (u in PING_URLS) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.setRequestProperty("User-Agent", "ClimaMDZ/1.2 (Android)")
                val code = c.responseCode
                c.disconnect()
                if (code in 200..299) return Pair(true, SystemClock.elapsedRealtime() - t0)
            } catch (e: Exception) {
            }
        }
        return Pair(false, SystemClock.elapsedRealtime() - t0)
    }

    private fun notifyOutage(ctx: Context) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val since = Store.p(ctx).getLong("last_ok", 0L)
            val txt = if (since > 0)
                "No pude revisar el clima desde las " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(since)) +
                    ". Revisá tu internet o datos; sigo reintentando solo."
            else
                "No pude revisar el clima. Revisá tu internet o datos; sigo reintentando solo."
            val open = PendingIntent.getActivity(
                ctx, 3, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, Alarm.CH_STATUS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("⚠ Clima MDZ sin conexión")
                .setContentText(txt)
                .setStyle(Notification.BigTextStyle().bigText(txt))
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }

    fun clearOutage(ctx: Context) {
        try {
            ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        } catch (e: Exception) {
        }
    }
}
