package ar.mdz.clima

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * Los sitios oficiales (SMN, Gobierno de Mendoza, INPRES) no mandan el permiso CORS, así que
 * la página no puede leerlos directamente. Acá se bajan desde Android y se entregan a la página
 * con el permiso agregado. Solo se atienden estos dominios y solo pedidos GET.
 */
object OfficialProxy {
    private val HOSTS = listOf("smn.gob.ar", "mendoza.gov.ar", "inpres.gob.ar")
    private const val MAX_BYTES = 6 * 1024 * 1024

    private val CORS = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Access-Control-Allow-Headers" to "*",
        "Access-Control-Allow-Methods" to "GET, OPTIONS",
        "Cache-Control" to "no-store"
    )

    private fun handles(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun empty(code: Int, reason: String) =
        WebResourceResponse("text/plain", "utf-8", code, reason, CORS, ByteArrayInputStream(ByteArray(0)))

    fun intercept(r: WebResourceRequest): WebResourceResponse? {
        val u = r.url
        if (r.isForMainFrame || u.scheme != "https" || !handles(u.host)) return null
        if (r.method == "OPTIONS") return empty(204, "No Content")
        if (r.method != "GET") return null
        return try {
            val c = URL(u.toString()).openConnection() as HttpURLConnection
            c.connectTimeout = 7000
            c.readTimeout = 9000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) ClimaMDZ/1.11")
            c.setRequestProperty("Accept", r.requestHeaders["Accept"] ?: "*/*")
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else c.errorStream
            val bytes = readLimited(stream)
            val ct = c.contentType ?: "application/octet-stream"
            val mime = ct.substringBefore(';').trim().lowercase()
            val declared = Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
            val isText = mime.startsWith("text/") || mime.contains("xml") || mime.contains("json") || mime.contains("javascript")
            // fetch().text() siempre lee UTF-8: si la página viene en otra codificación, se convierte.
            val body = if (isText) toUtf8(bytes, declared) else bytes
            val status = if (code in 300..399) 502 else code.coerceIn(200, 599)
            val reason = (c.responseMessage ?: "").ifBlank { if (status < 400) "OK" else "Error" }
            WebResourceResponse(mime, if (isText) "utf-8" else null, status, reason, CORS, ByteArrayInputStream(body))
        } catch (e: Exception) {
            empty(504, "Gateway Timeout")
        }
    }

    private fun readLimited(s: java.io.InputStream?): ByteArray {
        if (s == null) return ByteArray(0)
        return s.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (out.size() < MAX_BYTES) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
            out.toByteArray()
        }
    }

    private fun toUtf8(bytes: ByteArray, declared: String?): ByteArray {
        val cs: Charset? = try { declared?.let { Charset.forName(it) } } catch (e: Exception) { null }
        if (cs != null) return if (cs == Charsets.UTF_8) bytes else String(bytes, cs).toByteArray(Charsets.UTF_8)
        // Sin charset declarado: si los bytes son UTF-8 válido se dejan; si no, se asume Latin-1.
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
            bytes
        } catch (e: Exception) {
            String(bytes, Charsets.ISO_8859_1).toByteArray(Charsets.UTF_8)
        }
    }
}
