package ar.mdz.clima

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/** Alerta fuerte: notificación de pantalla completa + sonido por el canal de ALARMA + vibración. */
object Alarm {
    const val CH_ALERT = "alertas_urgentes"
    const val CH_MON = "vigilancia"

    private var player: MediaPlayer? = null
    private var appCtx: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { silence() }

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)

        val mon = NotificationChannel(CH_MON, "Vigilancia en segundo plano", NotificationManager.IMPORTANCE_LOW)
        mon.setShowBadge(false)
        nm.createNotificationChannel(mon)

        val existing = nm.getNotificationChannel(CH_ALERT)
        if (existing != null && nm.isNotificationPolicyAccessGranted && !existing.canBypassDnd()) {
            nm.deleteNotificationChannel(CH_ALERT)
        }
        if (nm.getNotificationChannel(CH_ALERT) == null) {
            val ch = NotificationChannel(CH_ALERT, "Alertas de clima y sismos", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Avisos urgentes de tormenta, granizo, viento, Zonda y sismos"
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 800)
            ch.setSound(null, null)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            ch.setBypassDnd(true)
            nm.createNotificationChannel(ch)
        }
    }

    fun fire(ctx: Context, id: Int, title: String, body: String, type: String, sound: Boolean, vibrate: Boolean) {
        val app = ctx.applicationContext
        appCtx = app
        ensureChannels(app)
        val nm = app.getSystemService(NotificationManager::class.java)
        val pf = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val alertIntent = Intent(app, AlertActivity::class.java)
        alertIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        alertIntent.putExtra("title", title)
        alertIntent.putExtra("body", body)
        alertIntent.putExtra("type", type)
        val fullPi = PendingIntent.getActivity(app, id, alertIntent, pf)

        val openIntent = Intent(app, MainActivity::class.java)
        openIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        openIntent.putExtra("alert", type)
        val openPi = PendingIntent.getActivity(app, id + 1000, openIntent, pf)

        val stopPi = PendingIntent.getBroadcast(app, 1, Intent(app, StopReceiver::class.java), pf)
        val dialPi = PendingIntent.getActivity(app, 2, Intent(Intent.ACTION_DIAL, Uri.parse("tel:911")), pf)

        val first = body.lines().firstOrNull() ?: ""
        val n = Notification.Builder(app, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(first)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .setFullScreenIntent(fullPi, true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi)
            .addAction(android.R.drawable.ic_menu_call, "Llamar 911", dialPi)
            .build()
        nm.notify(id, n)

        startAlarm(app, sound, vibrate)
        wakeScreen(app)
    }

    private fun startAlarm(app: Context, sound: Boolean, vibrate: Boolean) {
        silence()
        if (sound) {
            try {
                val am = app.getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                val vol = (max * 0.9).toInt()
                am.setStreamVolume(AudioManager.STREAM_ALARM, if (vol < 1) 1 else vol, 0)
            } catch (e: Exception) {
            }
            try {
                var uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                mp.setDataSource(app, uri)
                mp.isLooping = true
                mp.prepare()
                mp.start()
                player = mp
            } catch (e: Exception) {
                player = null
            }
        }
        if (vibrate) {
            try {
                val v = app.getSystemService(Vibrator::class.java)
                val effect = VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600, 300, 900, 500), 0)
                val aa = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
                v.vibrate(effect, aa)
            } catch (e: Exception) {
            }
        }
        handler.postDelayed(autoStop, 60000L)
    }

    private fun wakeScreen(app: Context) {
        try {
            val pm = app.getSystemService(PowerManager::class.java)
            val wl = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "clima:pantalla"
            )
            wl.acquire(10000L)
        } catch (e: Exception) {
        }
    }

    /** Corta sonido y vibración. */
    fun silence() {
        handler.removeCallbacks(autoStop)
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        try {
            appCtx?.getSystemService(Vibrator::class.java)?.cancel()
        } catch (e: Exception) {
        }
    }

    /** Lo usa el botón "Detener": corta todo y borra las notificaciones de alerta. */
    fun stop(ctx: Context) {
        appCtx = ctx.applicationContext
        silence()
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            for (sn in nm.activeNotifications) {
                if (sn.id != 1) nm.cancel(sn.id)
            }
        } catch (e: Exception) {
        }
    }
}
