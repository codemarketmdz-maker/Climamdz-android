package ar.mdz.clima

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Pantalla roja de alerta: aparece sobre el bloqueo y enciende la pantalla. */
class AlertActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render(intent)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun makeButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 18f
        b.setOnClickListener { onClick() }
        return b
    }

    private fun render(i: Intent) {
        val title = i.getStringExtra("title") ?: "Alerta"
        val body = i.getStringExtra("body") ?: ""
        val type = i.getStringExtra("type") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF8B1A1A.toInt())
        root.setPadding(dp(24), dp(48), dp(24), dp(24))

        val t = TextView(this)
        t.text = title
        t.textSize = 26f
        t.setTextColor(Color.WHITE)
        t.setTypeface(null, Typeface.BOLD)
        root.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val b = TextView(this)
        b.text = body
        b.textSize = 18f
        b.setTextColor(Color.WHITE)
        b.setPadding(0, dp(16), 0, dp(24))
        val sv = ScrollView(this)
        sv.addView(b)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)

        root.addView(makeButton("🔕 Detener alarma") { Alarm.stop(this) }, lp)
        root.addView(makeButton("📞 Llamar al 911") {
            Alarm.stop(this)
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:911")))
        }, lp)
        root.addView(makeButton("Abrir app / qué hacer") {
            Alarm.stop(this)
            val open = Intent(this, MainActivity::class.java)
            open.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            open.putExtra("alert", type)
            startActivity(open)
            finish()
        }, lp)

        setContentView(root)
    }
}
