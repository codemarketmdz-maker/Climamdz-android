package ar.mdz.clima

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    companion object {
        @Volatile
        var visible = false
        const val BASE = "https://appassets.androidplatform.net/assets/www/index.html"
    }

    private lateinit var web: WebView
    private var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, true, false)
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        Alarm.ensureChannels(this)
        web.loadUrl(urlFor(intent))
    }

    private fun alertParam(i: Intent?): String {
        val a = i?.getStringExtra("alert") ?: return ""
        return a.filter { it.isLetterOrDigit() }
    }

    private fun urlFor(i: Intent?): String {
        val a = alertParam(i)
        return if (a.isEmpty()) BASE else "$BASE?alert=$a"
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val a = alertParam(intent)
        if (a.isNotEmpty()) {
            web.evaluateJavascript("if(typeof openSOS==='function')openSOS('$a')", null)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        web.onResume()
        if (Store.p(this).contains("state") && MonitorService.instance == null) startMonitor()
        runSetup()
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onDestroy() {
        dialog?.dismiss()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun startMonitor() {
        try {
            MonitorService.start(this)
        } catch (e: Exception) {
        }
    }

    // ---------- permisos paso a paso ----------
    private fun asked(k: String): Boolean = Store.p(this).getBoolean("ask_$k", false)

    private fun mark(k: String) {
        Store.p(this).edit().putBoolean("ask_$k", true).apply()
    }

    private fun clearAsked() {
        val e = Store.p(this).edit()
        for (k in listOf("loc", "notif", "bgloc", "dnd", "batt", "fsi")) e.remove("ask_$k")
        e.apply()
    }

    private fun hasLoc(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun explain(title: String, msg: String, go: () -> Unit) {
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("Continuar") { _, _ -> go() }
            .show()
    }

    private fun runSetup() {
        if (dialog?.isShowing == true) return
        val nm = getSystemService(NotificationManager::class.java)
        val pm = getSystemService(PowerManager::class.java)

        if (!hasLoc() && !asked("loc")) {
            mark("loc")
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 21
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !asked("notif")
        ) {
            mark("notif")
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
            return
        }
        if (Build.VERSION.SDK_INT >= 29 && hasLoc() &&
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            !asked("bgloc")
        ) {
            mark("bgloc")
            explain(
                "Ubicación todo el tiempo",
                "Para avisarte con la pantalla apagada necesito conocer tu ubicación aunque la app esté cerrada. " +
                    "En la próxima pantalla elegí «Permitir todo el tiempo»."
            ) { requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 23) }
            return
        }
        if (!nm.isNotificationPolicyAccessGranted && !asked("dnd")) {
            mark("dnd")
            explain(
                "Alertas aunque esté en silencio",
                "Activá «Clima MDZ» en la lista de acceso a No molestar para que las alertas urgentes suenen y vibren igual."
            ) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            return
        }
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !asked("batt")) {
            mark("batt")
            explain(
                "Sin restricciones de batería",
                "Elegí «Permitir» para que Android no duerma la app y las revisiones sigan con la pantalla apagada."
            ) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() && !asked("fsi")) {
            mark("fsi")
            explain(
                "Alerta en pantalla completa",
                "Permití las notificaciones a pantalla completa para que la alerta encienda la pantalla y se vea sobre el bloqueo."
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        Alarm.ensureChannels(this)
    }

    // ---------- puente con la página ----------
    inner class Bridge {
        @JavascriptInterface
        fun saveState(json: String) {
            Store.p(this@MainActivity).edit().putString("state", json).apply()
            runOnUiThread {
                if (MonitorService.instance == null) startMonitor()
            }
        }

        @JavascriptInterface
        fun setup() {
            runOnUiThread {
                clearAsked()
                runSetup()
            }
        }

        @JavascriptInterface
        fun testAlarm() {
            val app = applicationContext
            Handler(Looper.getMainLooper()).postDelayed({
                Alarm.fire(
                    app, 99, "🧪 Prueba de alarma",
                    "Si ves y escuchás esto con la pantalla apagada, los avisos funcionan.\n👉 Podés tocar «Detener».",
                    "hail", true, true
                )
            }, 10000L)
        }
    }
}
