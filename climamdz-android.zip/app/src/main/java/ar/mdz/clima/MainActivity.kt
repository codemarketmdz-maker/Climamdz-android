package ar.mdz.clima

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {

    companion object {
        @Volatile
        var visible = false
        const val BASE = "https://appassets.androidplatform.net/assets/www/index.html"
    }

    private lateinit var web: WebView
    private var dialog: AlertDialog? = null
    private val ui = Handler(Looper.getMainLooper())
    private var testRun: Runnable? = null
    private var testLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, true, false)
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        Alarm.ensureChannels(this)
        if (alertParam(intent).isNotEmpty()) Alarm.stop(this) // la abrieron desde la notificación: ya la leyeron
        web.loadUrl(urlFor(intent))
    }

    private fun alertParam(i: Intent?): String {
        val a = i?.getStringExtra("alert") ?: return ""
        return a.filter { it.isLetterOrDigit() }
    }

    private fun urlFor(i: Intent?): String {
        val a = alertParam(i)
        return if (a.isEmpty()) BASE else "$BASE?alert=$a"
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val a = alertParam(intent)
        if (a.isNotEmpty()) {
            Alarm.stop(this)
            web.evaluateJavascript("if(typeof openSOS==='function')openSOS('$a')", null)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        web.onResume()
        if (Alarm.isRinging()) Alarm.stop(this) // abrieron la app: cortan sonido y vibración
        if (Store.p(this).contains("state") && MonitorService.instance == null) startMonitor()
        runSetup()
        js("window.onNativeResume&&onNativeResume()")
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onDestroy() {
        dialog?.dismiss()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun startMonitor() {
        try {
            MonitorService.start(this)
        } catch (e: Exception) {
        }
    }

    private fun js(code: String) {
        try {
            web.evaluateJavascript(code, null)
        } catch (e: Exception) {
        }
    }

    private fun permJson(): String {
        val nm = getSystemService(NotificationManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        val o = JSONObject()
        o.put("loc", hasLoc())
        o.put(
            "bgloc",
            if (Build.VERSION.SDK_INT >= 29)
                checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
            else true
        )
        o.put("notif", nm.areNotificationsEnabled())
        o.put("dnd", nm.isNotificationPolicyAccessGranted)
        o.put("batt", pm.isIgnoringBatteryOptimizations(packageName))
        o.put("fsi", if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true)
        return o.toString()
    }

    private fun toneJson(): String {
        val o = JSONObject()
        o.put("name", Alarm.toneName(this))
        return o.toString()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 31 || resultCode != RESULT_OK || data == null) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33)
            data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        else
            data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        if (uri == null) {
            Alarm.saveTone(this, null, null)
        } else {
            val name = try {
                RingtoneManager.getRingtone(this, uri)?.getTitle(this)
            } catch (e: Exception) {
                null
            }
            Alarm.saveTone(this, uri, name)
        }
        js("window.onNative&&onNative('tone'," + toneJson() + ")")
        Alarm.playPreview(this)
    }

    private fun cancelTest() {
        testRun?.let { ui.removeCallbacks(it) }
        testRun = null
        try {
            val l = testLock
            if (l != null && l.isHeld) l.release()
        } catch (e: Exception) {
        }
        testLock = null
    }

    // ---------- permisos paso a paso ----------
    private fun asked(k: String): Boolean = Store.p(this).getBoolean("ask_$k", false)

    private fun mark(k: String) {
        Store.p(this).edit().putBoolean("ask_$k", true).apply()
    }

    private fun clearAsked() {
        val e = Store.p(this).edit()
        for (k in listOf("loc", "notif", "bgloc", "dnd", "batt", "fsi")) e.remove("ask_$k")
        e.apply()
    }

    private fun hasLoc(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun explain(title: String, msg: String, go: () -> Unit) {
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("Continuar") { _, _ -> go() }
            .show()
    }

    private fun runSetup() {
        if (dialog?.isShowing == true) return
        val nm = getSystemService(NotificationManager::class.java)
        val pm = getSystemService(PowerManager::class.java)

        if (!hasLoc() && !asked("loc")) {
            mark("loc")
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 21
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !asked("notif")
        ) {
            mark("notif")
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
            return
        }
        if (Build.VERSION.SDK_INT >= 29 && hasLoc() &&
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            !asked("bgloc")
        ) {
            mark("bgloc")
            explain(
                "Ubicación todo el tiempo",
                "Para avisarte con la pantalla apagada necesito conocer tu ubicación aunque la app esté cerrada. " +
                    "En la próxima pantalla elegí «Permitir todo el tiempo»."
            ) { requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 23) }
            return
        }
        if (!nm.isNotificationPolicyAccessGranted && !asked("dnd")) {
            mark("dnd")
            explain(
                "Alertas aunque esté en silencio",
                "Activá «Clima MDZ» en la lista de acceso a No molestar para que las alertas urgentes suenen y vibren igual."
            ) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            return
        }
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !asked("batt")) {
            mark("batt")
            explain(
                "Sin restricciones de batería",
                "Elegí «Permitir» para que Android no duerma la app y las revisiones sigan con la pantalla apagada."
            ) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() && !asked("fsi")) {
            mark("fsi")
            explain(
                "Alerta en pantalla completa",
                "Permití las notificaciones a pantalla completa para que la alerta encienda la pantalla y se vea sobre el bloqueo."
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        Alarm.ensureChannels(this)
    }

    // ---------- puente con la página ----------
    inner class Bridge {
        @JavascriptInterface
        fun saveState(json: String) {
            Store.p(this@MainActivity).edit().putString("state", json).apply()
            runOnUiThread {
                if (MonitorService.instance == null) startMonitor()
            }
        }

        @JavascriptInterface
        fun setup() {
            runOnUiThread {
                clearAsked()
                runSetup()
            }
        }

        @JavascriptInterface
        fun licenseStatus(): String = License.status(this@MainActivity).toString()

        @JavascriptInterface
        fun activateLicense(key: String): String {
            val r = License.activate(this@MainActivity, key)
            if (r.optBoolean("ok")) runOnUiThread { if (MonitorService.instance == null) startMonitor() }
            return r.toString()
        }

        @JavascriptInterface
        fun copyText(t: String) {
            runOnUiThread {
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("ClimaMDZ", t))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun readClipboard(): String {
            return try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
            } catch (e: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun permStatus(): String = permJson()

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun toneInfo(): String = toneJson()

        @JavascriptInterface
        fun pickTone() {
            runOnUiThread {
                try {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    i.putExtra(
                        RingtoneManager.EXTRA_RINGTONE_TYPE,
                        RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE
                    )
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Tono de las alarmas")
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Alarm.toneUri(this@MainActivity))
                    @Suppress("DEPRECATION")
                    startActivityForResult(i, 31)
                } catch (e: Exception) {
                    js("window.onNative&&onNative('toneErr',{})")
                }
            }
        }

        @JavascriptInterface
        fun previewTone() {
            runOnUiThread { Alarm.playPreview(this@MainActivity) }
        }

        @JavascriptInterface
        fun healthJson(): String = Health.json(this@MainActivity)

        /** La página (con la app abierta) avisa si pudo bajar datos, para que el estado no quede viejo. */
        @JavascriptInterface
        fun reportCheck(ok: Boolean) {
            if (ok) Health.recordOk(this@MainActivity) else Health.recordFail(this@MainActivity, false)
        }

        /** Prueba real de conexión: baja un dato de la fuente de clima. Responde con onNative('conn', {...}). */
        @JavascriptInterface
        fun testConnection() {
            val app = applicationContext
            Thread {
                val net = Health.hasNet(app)
                val r = Health.ping()
                val o = JSONObject()
                o.put("net", net)
                o.put("ok", r.first)
                o.put("ms", r.second)
                if (r.first) Health.recordOk(app)
                runOnUiThread {
                    // si el servicio estaba caído, se lo reactiva
                    var restarted = false
                    if (MonitorService.instance == null && Store.p(app).contains("state")) {
                        startMonitor()
                        restarted = true
                    }
                    o.put("restarted", restarted)
                    js("window.onNative&&onNative('conn'," + o.toString() + ")")
                }
            }.start()
        }

        @JavascriptInterface
        fun restartService() {
            runOnUiThread { startMonitor() }
        }

        @JavascriptInterface
        fun isRinging(): Boolean = Alarm.isRinging()

        @JavascriptInterface
        fun stopAlarm() {
            runOnUiThread { Alarm.stop(this@MainActivity) }
        }

        @JavascriptInterface
        fun cancelTest() {
            runOnUiThread { this@MainActivity.cancelTest() }
        }

        /** Suena a los 10 s (hay tiempo de apagar la pantalla). Mantiene el CPU despierto para que no se atrase. */
        @JavascriptInterface
        fun testAlarm() {
            runOnUiThread {
                val app = applicationContext
                this@MainActivity.cancelTest()
                try {
                    val pm = getSystemService(PowerManager::class.java)
                    val l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clima:prueba")
                    l.acquire(20000L)
                    testLock = l
                } catch (e: Exception) {
                }
                val r = Runnable {
                    Store.p(app).edit().putLong("test_fired", System.currentTimeMillis()).apply()
                    Alarm.fire(
                        app, 99, "🧪 Prueba de alarma",
                        "Si ves y escuchás esto con la pantalla apagada, los avisos funcionan.\n👉 Podés tocar «Detener».",
                        "hail", true, true
                    )
                    this@MainActivity.cancelTest()
                }
                testRun = r
                ui.postDelayed(r, 10000L)
            }
        }
    }
}
