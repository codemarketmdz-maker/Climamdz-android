package ar.mdz.clima

import android.content.Context
import android.content.SharedPreferences

object Store {
    fun p(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("clima", Context.MODE_PRIVATE)
}
