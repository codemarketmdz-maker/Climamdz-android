package ar.mdz.clima

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Store.p(context).contains("state")) {
            try {
                MonitorService.start(context)
            } catch (e: Exception) {
            }
        }
    }
}
