package ar.mdz.clima

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Lo despierta la alarma del sistema cada ~5 minutos (también con el celular en reposo). */
class TickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val s = MonitorService.instance
        if (s != null) {
            s.runCheck()
        } else {
            try {
                MonitorService.start(context)
            } catch (e: Exception) {
            }
        }
    }
}
