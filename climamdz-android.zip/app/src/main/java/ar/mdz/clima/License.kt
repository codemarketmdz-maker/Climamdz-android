package ar.mdz.clima

import android.content.Context
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Licencias sin servidor: la clave la firma el generador (clave privada de CodeMarket) y la app solo
 * necesita la clave pública para comprobarla. Formato:  CMDZ1.<datos>.<firma>
 * datos = plan|vence(yyyyMMdd)|idDispositivo(o *)|emitida(yyyyMMdd)|nombre
 * Prueba gratis de 3 días desde la primera apertura; luego hace falta una clave vigente.
 */
object License {
    const val TRIAL_DAYS = 3
    private const val DAY = 86400000L

    /** Clave pública (X.509 / Base64) del par generado junto con "clave-privada.json". */
    private const val PUB = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEXV1SnMaZVi0xzru+qeMWidagosq6cNiUDZubH29tUTbpLhl1NuD+Yr4HTOKKn7osfaw6ADejWX2k2jbTaJcWdg=="

    class Parsed(val plan: String, val expiry: Long, val device: String, val name: String)

    /** ID corto que el cliente le pasa al vendedor para que le emita una clave atada a su celular. */
    fun deviceId(ctx: Context): String {
        val raw = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "x"
        val h = MessageDigest.getInstance("SHA-256").digest(("climamdz|" + raw).toByteArray(Charsets.UTF_8))
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var bits = 0L
        for (i in 0 until 5) bits = (bits shl 8) or (h[i].toLong() and 0xff)
        val sb = StringBuilder()
        for (i in 7 downTo 0) sb.append(abc[((bits shr (i * 5)) and 31).toInt()])
        return sb.substring(0, 4) + "-" + sb.substring(4, 8)
    }

    private fun norm(id: String) = id.replace("-", "").replace(" ", "").uppercase(Locale.ROOT)

    private fun b64(s: String): ByteArray = Base64.decode(s, Base64.URL_SAFE)

    private fun endOfDay(yyyymmdd: String): Long {
        val d = SimpleDateFormat("yyyyMMdd", Locale.US).parse(yyyymmdd) ?: throw IllegalArgumentException()
        val c = Calendar.getInstance()
        c.time = d
        c.set(Calendar.HOUR_OF_DAY, 23)
        c.set(Calendar.MINUTE, 59)
        c.set(Calendar.SECOND, 59)
        return c.timeInMillis
    }

    /** Devuelve los datos si la firma es válida y la clave sirve para ESTE celular; si no, lanza con el motivo. */
    fun parse(ctx: Context, keyRaw: String): Parsed {
        val key = keyRaw.filter { !it.isWhitespace() }
        val parts = key.split(".")
        if (parts.size != 3 || parts[0] != "CMDZ1") throw IllegalArgumentException("La clave no tiene el formato correcto. Copiala completa.")
        val payload: ByteArray
        val sig: ByteArray
        try {
            payload = b64(parts[1])
            sig = b64(parts[2])
        } catch (e: Exception) {
            throw IllegalArgumentException("La clave está incompleta. Copiala completa.")
        }
        val ok = try {
            val pk = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(PUB, Base64.DEFAULT)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(pk)
            v.update(payload)
            v.verify(sig)
        } catch (e: Exception) {
            false
        }
        if (!ok) throw IllegalArgumentException("La clave no es válida (revisá que esté completa y sin cambios).")
        val f = String(payload, Charsets.UTF_8).split("|")
        if (f.size < 5) throw IllegalArgumentException("La clave no es válida.")
        val dev = f[2]
        if (dev != "*" && norm(dev) != norm(deviceId(ctx))) {
            throw IllegalArgumentException("Esta clave es para otro celular. Pedí una con el ID de este equipo.")
        }
        val exp = try {
            endOfDay(f[1])
        } catch (e: Exception) {
            throw IllegalArgumentException("La clave no es válida.")
        }
        return Parsed(f[0], exp, dev, f[4])
    }

    private fun savedKey(ctx: Context): Parsed? {
        val k = Store.p(ctx).getString("lic_key", null) ?: return null
        return try {
            parse(ctx, k)
        } catch (e: Exception) {
            null
        }
    }

    /** Estado actual: state = trial | licensed | expired. */
    fun status(ctx: Context): JSONObject {
        val p = Store.p(ctx)
        val now = System.currentTimeMillis()
        val seen = p.getLong("lic_seen", 0L)
        // Si el reloj se atrasó (para "estirar" la prueba o la licencia) no se la considera válida
        val tamper = seen > 0 && now < seen - 6L * 3600_000L
        if (!tamper && now > seen) p.edit().putLong("lic_seen", now).apply()
        if (!p.contains("trial_start")) p.edit().putLong("trial_start", now).apply()
        val trialEnd = p.getLong("trial_start", now) + TRIAL_DAYS * DAY

        val o = JSONObject()
        o.put("device", deviceId(ctx))
        o.put("tamper", tamper)
        val lic = savedKey(ctx)
        if (!tamper && lic != null && now <= lic.expiry) {
            o.put("state", "licensed")
            o.put("plan", lic.plan)
            o.put("expiry", lic.expiry)
            o.put("msLeft", lic.expiry - now)
            o.put("name", lic.name)
        } else if (!tamper && now < trialEnd) {
            o.put("state", "trial")
            o.put("msLeft", trialEnd - now)
        } else {
            o.put("state", "expired")
            o.put("msLeft", 0L)
            o.put("reason", if (tamper) "clock" else if (lic != null) "license" else "trial")
            if (lic != null) o.put("expiry", lic.expiry)
        }
        return o
    }

    fun isActive(ctx: Context): Boolean = status(ctx).optString("state") != "expired"

    /** Guarda la clave si es válida. Devuelve {ok, msg}. */
    fun activate(ctx: Context, key: String): JSONObject {
        val r = JSONObject()
        try {
            val np = parse(ctx, key)
            val cur = savedKey(ctx)
            if (np.expiry < System.currentTimeMillis()) {
                val d = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(np.expiry)
                throw IllegalArgumentException("Esa clave ya venció el $d. Pedí una nueva.")
            }
            val f = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            if (cur != null && cur.expiry > np.expiry) {
                r.put("ok", true)
                r.put("msg", "Ya tenías una licencia que vence después (" + f.format(cur.expiry) + "). Se mantiene esa.")
            } else {
                Store.p(ctx).edit().putString("lic_key", key.filter { !it.isWhitespace() }).apply()
                r.put("ok", true)
                r.put("msg", "✔ Licencia activada. Vence el " + f.format(np.expiry) + ".")
            }
        } catch (e: IllegalArgumentException) {
            r.put("ok", false)
            r.put("msg", e.message ?: "Clave no válida.")
        }
        return r
    }
}
