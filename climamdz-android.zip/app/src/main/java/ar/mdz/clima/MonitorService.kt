package ar.mdz.clima

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Servicio en primer plano: cada ~5 min revisa el clima, el satélite y los sismos
 * (con la misma lógica de la app web, corriendo en un WebView invisible) y dispara la alarma.
 */
class MonitorService : Service() {

    companion object {
        @Volatile
        var instance: MonitorService? = null
        const val ACTION_TICK = "ar.mdz.clima.TICK"
        const val INTERVAL_MS = 5L * 60L * 1000L

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, MonitorService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var busy = false
    private var wl: PowerManager.WakeLock? = null
    private var lm: LocationManager? = null

    private val watchdog = Runnable {
        // la revisión no contestó a tiempo: cuenta como falla
        Health.recordFail(this)
        updateText("Sin respuesta a las " + hhmm() + " · reintenta en 5 min")
        finishCheck()
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Alarm.ensureChannels(this)
        startFg("Iniciando…")
        startLocation()
        handler.postDelayed({ runCheck() }, 4000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg("Vigilando tu ubicación y tus fincas")
        if (intent != null && intent.action == ACTION_TICK) runCheck()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        try {
            lm?.removeUpdates(locListener)
        } catch (e: Exception) {
        }
        destroyWeb()
        releaseWl()
        super.onDestroy()
    }

    // ---------- notificación fija ----------
    private fun buildFg(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, Alarm.CH_MON)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Clima MDZ vigilando")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun startFg(text: String) {
        val n = buildFg(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun updateText(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(1, buildFg(text))
        } catch (e: Exception) {
        }
    }

    private fun hhmm(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    // ---------- ubicación ----------
    private fun hasLocPerm(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startLocation() {
        try {
            if (!hasLocPerm()) return
            val m = getSystemService(LocationManager::class.java)
            lm = m
            if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 300000L, 300f, locListener)
            }
        } catch (e: Exception) {
        }
    }

    /** Reemplaza la ubicación guardada ("gps") por la última conocida del celular. */
    private fun applyNativeLocation(locs: JSONArray) {
        try {
            if (!hasLocPerm()) return
            val m = getSystemService(LocationManager::class.java)
            var best: Location? = null
            for (p in m.getProviders(true)) {
                val l: Location? = try {
                    m.getLastKnownLocation(p)
                } catch (e: SecurityException) {
                    null
                }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            if (best == null) return
            if (System.currentTimeMillis() - best.time > 6L * 3600L * 1000L) return
            for (i in 0 until locs.length()) {
                val o = locs.getJSONObject(i)
                if (o.optString("id") == "gps") {
                    o.put("lat", best.latitude)
                    o.put("lon", best.longitude)
                }
            }
        } catch (e: Exception) {
        }
    }

    // ---------- ciclo de revisión ----------
    private fun scheduleNext() {
        try {
            Health.recordNext(this, System.currentTimeMillis() + INTERVAL_MS)
            val am = getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(
                this, 7,
                Intent(this, TickReceiver::class.java).setAction(ACTION_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + INTERVAL_MS,
                pi
            )
        } catch (e: Exception) {
        }
    }

    fun runCheck() {
        scheduleNext()
        if (busy) return
        val prefs = Store.p(this)
        val stateJson = prefs.getString("state", null)
        if (stateJson == null) {
            updateText("Abrí la app una vez para elegir tus ubicaciones")
            return
        }
        if (!License.isActive(this)) {
            updateText("Licencia vencida · abrí la app para renovar")
            return
        }
        if (MainActivity.visible) {
            updateText("App abierta · " + hhmm())
            return
        }
        busy = true
        acquireWl()
        try {
            val st = JSONObject(stateJson)
            val locs = st.optJSONArray("locs") ?: JSONArray()
            applyNativeLocation(locs)
            val arg = JSONObject()
            arg.put("cfg", st.optJSONObject("cfg") ?: JSONObject())
            arg.put("locs", locs)
            arg.put("notified", JSONObject(prefs.getString("notified", "{}") ?: "{}"))
            val js = "runCheck(" + arg.toString() + ")"
            withWeb { w -> w.evaluateJavascript(js, null) }
            handler.postDelayed(watchdog, 70000L)
        } catch (e: Exception) {
            Health.recordFail(this)
            finishCheck()
        }
    }

    private fun acquireWl() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            val l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clima:revision")
            l.acquire(90000L)
            wl = l
        } catch (e: Exception) {
        }
    }

    private fun releaseWl() {
        try {
            val l = wl
            if (l != null && l.isHeld) l.release()
        } catch (e: Exception) {
        }
        wl = null
    }

    private fun finishCheck() {
        handler.removeCallbacks(watchdog)
        busy = false
        destroyWeb()
        releaseWl()
    }

    // ---------- WebView invisible ----------
    private fun createWeb(): WebView {
        val w = WebView(applicationContext)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        w.addJavascriptInterface(BgBridge(), "AndroidBg")
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                ready = true
                val p = pending
                pending = null
                if (p != null) p()
            }
        }
        ready = false
        w.loadUrl("https://appassets.androidplatform.net/assets/www/bg.html")
        return w
    }

    private fun withWeb(job: (WebView) -> Unit) {
        val w = web ?: createWeb().also { web = it }
        if (ready) job(w) else pending = { job(w) }
    }

    private fun destroyWeb() {
        pending = null
        ready = false
        try {
            web?.destroy()
        } catch (e: Exception) {
        }
        web = null
    }

    inner class BgBridge {
        @JavascriptInterface
        fun onResult(json: String) {
            handler.post { handleResult(json) }
        }
    }

    private fun handleResult(json: String) {
        try {
            val r = JSONObject(json)
            val prefs = Store.p(this)
            val notified = r.optJSONObject("notified")
            prefs.edit().putString("notified", if (notified != null) notified.toString() else "{}").apply()
            val st = JSONObject(prefs.getString("state", "{}") ?: "{}")
            val cfg = st.optJSONObject("cfg")
            val sound = cfg?.optBoolean("sound", true) ?: true
            val vib = cfg?.optBoolean("vibrate", true) ?: true
            val full = cfg?.optBoolean("fullscreen", true) ?: true
            val rep = cfg?.optBoolean("repeatAlarm", true) ?: true
            val alerts = r.optJSONArray("alerts") ?: JSONArray()
            for (i in 0 until alerts.length()) {
                val a = alerts.getJSONObject(i)
                val nid = (a.optString("tag").hashCode() and 0x7fffffff) % 100000 + 10
                Alarm.fire(this, nid, a.optString("title"), a.optString("body"), a.optString("type"), sound, vib, full, rep)
            }
            if (r.optBoolean("ok")) {
                Health.recordOk(this)
                var t = "Última revisión " + hhmm()
                if (alerts.length() > 0) t += " · " + alerts.length() + " aviso(s)"
                updateText(t)
            } else {
                Health.recordFail(this)
                val why = if (Health.hasNet(this)) "Sin datos" else "Sin internet"
                updateText(why + " a las " + hhmm() + " · reintenta en 5 min")
            }
        } catch (e: Exception) {
        }
        finishCheck()
    }
}
