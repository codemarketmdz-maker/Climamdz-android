package com.codemarket.climamdz.model

data class Finca(
    val id: Int,
    val nombre: String,
    val ubicacion: String,
    val estado: String
)

data class AlertaTipo(
    val id: String,
    val titulo: String,
    val descripcion: String,
    val recomendacion: String,
    val activa: Boolean
)
