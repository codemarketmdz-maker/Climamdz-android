package com.codemarket.climamdz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.*
import com.codemarket.climamdz.model.AlertaTipo
import com.codemarket.climamdz.ui.screens.*
import com.codemarket.climamdz.ui.theme.ClimaMDZTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClimaMDZTheme {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val navController = rememberNavController()
    var selectedAlert by remember { mutableStateOf<AlertaTipo?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF1E293B)) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                    label = { Text("Inicio") },
                    selected = false,
                    onClick = { navController.navigate("home") }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Simulación") },
                    label = { Text("Simulación") },
                    selected = false,
                    onClick = { navController.navigate("simulation") }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.LocationOn, contentDescription = "Fincas") },
                    label = { Text("Fincas") },
                    selected = false,
                    onClick = { navController.navigate("fincas") }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Ajustes") },
                    label = { Text("Ajustes") },
                    selected = false,
                    onClick = { navController.navigate("settings") }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(
                    onNavigateToSimulation = { navController.navigate("simulation") },
                    onSelectAlert = { alert ->
                        selectedAlert = alert
                        navController.navigate("alert_detail")
                    }
                )
            }
            composable("simulation") {
                SimulationScreen(
                    onOpenAlert = {
                        navController.navigate("alert_detail")
                    }
                )
            }
            composable("fincas") {
                FincasScreen()
            }
            composable("settings") {
                SettingsScreen()
            }
            composable("alert_detail") {
                AlertDetailScreen(alerta = selectedAlert) {
                    navController.popBackStack()
                }
            }
        }
    }
}
