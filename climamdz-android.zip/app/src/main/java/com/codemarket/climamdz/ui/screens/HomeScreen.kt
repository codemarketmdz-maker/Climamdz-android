package com.codemarket.climamdz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codemarket.climamdz.model.AlertaTipo

@Composable
fun HomeScreen(onNavigateToSimulation: () -> Unit, onSelectAlert: (AlertaTipo) -> Unit) {
    val alertas = listOf(
        AlertaTipo("1", "Tormenta fuerte", "Lluvia intensa y actividad eléctrica", "Buscá refugio firme, alejate de ventanas, árboles y cables. No cruces zanjones.", true),
        AlertaTipo("2", "Tormenta severa / granizo", "Topes de nube muy fríos", "Protegé maquinaria y vehículos bajo techo.", true),
        AlertaTipo("3", "Viento Zonda", "Viento seco y cálido del oeste", "Evitá hacer fuego y asegurar objetos sueltos.", true),
        AlertaTipo("4", "Viento fuerte", "Ráfagas por encima del umbral", "Alejate de estructuras precarias y cartelería.", true),
        AlertaTipo("5", "Sismo", "Sismos cercanos detectados en red", "Ubicate bajo zonas seguras antisísmicas.", true),
        AlertaTipo("6", "Helada", "Mínima pronosticada cercana o bajo 0 °C", "Encendé sistemas de calefacción o riego antihelada.", true)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        item {
            Text("Clima MDZ", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Mendoza · Vigilancia del tiempo y sismos", fontSize = 14.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToSimulation() }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🚀 PROBAR SIMULACIÓN (3 días gratis)", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Satélite infrarrojo + viento en altura en tiempo acelerado.", color = Color.White, fontSize = 14.sp)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text("Tipos de Avisos y Recomendaciones", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(alertas) { alerta ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onSelectAlert(alerta) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(alerta.titulo, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(alerta.descripcion, color = Color.Gray, fontSize = 13.sp)
                }
            }
        }
    }
}
