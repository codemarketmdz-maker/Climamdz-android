package com.codemarket.climamdz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SimulationScreen(onOpenAlert: () -> Unit) {
    var tiempoRestante by remember { mutableStateOf("3 h 14 min") }
    var distancia by remember { mutableStateOf("129 km") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        Text("SIMULACIÓN · tiempo acelerado", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Satélite infrarrojo + viento en altura", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        
        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .background(Color(0xFF1E293B)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("CORDILLERA ➔ 30km ➔ 70km", color = Color.Yellow, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("⛈ Tormenta fuerte · sudeste 40 km/h", color = Color.Red, fontWeight = FontWeight.Bold)
                Text("A $distancia de tu finca", color = Color.White, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(tiempoRestante, color = Color(0xFF38BDF8), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Hacia dónde va y a qué velocidad", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Línea punteada activa hacia el sudeste a 40 km/h.", color = Color.Gray, fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onOpenAlert,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                modifier = Modifier.weight(1f)
            ) {
                Text("Simular Alerta Sonora")
            }
            OutlinedButton(
                onClick = { tiempoRestante = "3 h 14 min"; distancia = "129 km" },
                modifier = Modifier.weight(1f)
            ) {
                Text("Reiniciar", color = Color.White)
            }
        }
    }
}
