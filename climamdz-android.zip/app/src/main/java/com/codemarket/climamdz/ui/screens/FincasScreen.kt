package com.codemarket.climamdz.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codemarket.climamdz.model.Finca

@Composable
fun FincasScreen() {
    val fincas = remember {
        mutableStateListOf(
            Finca(1, "Finca Luján de Cuyo", "Lateral Sur Ruta 40", "Sin alertas"),
            Finca(2, "Finca Maipú", "Calle Maza", "Seguimiento satelital activo")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(16.dp)
    ) {
        Text("Mis Fincas y Zonas", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Alertas automáticas por cada ubicación", fontSize = 13.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(fincas) { finca ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(finca.nombre, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(finca.ubicacion, color = Color.Gray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Estado: ${finca.estado}", color = Color(0xFF38BDF8), fontSize = 12.sp)
                    }
                }
            }
        }

        Button(
            onClick = { },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("+ Agregar nueva finca")
        }
    }
}
