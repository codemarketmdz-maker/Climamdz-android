/* Seguimiento de tormentas: ¿se dirige hacia mi ubicación y cuándo llega?
 *
 * 1) IMÁGENES: del satélite GOES-East (NASA GIBS, banda IR) se leen dos imágenes separadas ~30 min alrededor del lugar.
 *    - Las celdas son zonas conectadas con topes <= -45 °C (convección profunda).
 *    - El movimiento sale de comparar las dos imágenes (correlación cruzada del campo frío): cuánto y hacia dónde se corrió.
 * 2) DATOS: viento en altura (700 y 500 hPa, Open-Meteo), que es el que "empuja" a las tormentas.
 * 3) Solo si ambos concuerdan en el rumbo se confirma. Con imágenes o datos solos se avisa pero indicándolo.
 * 4) La imagen de GIBS llega con ~30-40 min de demora: las celdas se adelantan a "ahora" según su velocidad.
 * 5) Se avisa si la celda viene hacia el lugar y (está a <= 30 km del borde) o (llega en <= aviso previo elegido: 30/45/60/90 min).
 */
(function (g) {
  'use strict';
  const CT = () => g._ct;
  const LAYER = 'GOES-East_ABI_Band13_Clean_Infrared';
  const STEP = 4, HALF = 150, N = Math.round(2 * HALF / STEP) + 1, MID = (N - 1) / 2;   // grilla de 4 km, ±150 km
  const FRAME_MS = 600000;
  const NEAR_KM = 30;
  const CELL_C = -45;              // tope de nube que define una celda
  const SHIFT_MAX = 15;            // corrimiento máximo entre imágenes: 15 celdas = 60 km
  const rad = d => d * Math.PI / 180;

  /* ---------- imágenes (con hora) ---------- */
  const tileCache = new Map();
  const isoT = t => new Date(t).toISOString().slice(0, 19) + 'Z';
  function tile(time, tx, ty) {
    const key = time + '/' + tx + '/' + ty;
    if (tileCache.size > 48) tileCache.delete(tileCache.keys().next().value);
    if (!tileCache.has(key)) tileCache.set(key, (async () => {
      const c = new AbortController(), t = setTimeout(() => c.abort(), 10000);
      try {
        const tt = time.indexOf('default') === 0 ? 'default' : time;
        const r = await fetch('https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/' + LAYER + '/default/' + tt + '/GoogleMapsCompatible_Level6/6/' + ty + '/' + tx + '.png', { signal: c.signal });
        if (!r.ok) return null;
        const bmp = await createImageBitmap(await r.blob());
        const cv = new OffscreenCanvas(bmp.width, bmp.height), cx = cv.getContext('2d', { willReadFrequently: true });
        cx.drawImage(bmp, 0, 0);
        return cx.getImageData(0, 0, bmp.width, bmp.height).data;
      } catch (e) { return null; } finally { clearTimeout(t); }
    })());
    return tileCache.get(key);
  }
  const opaqueFrac = d => { if (!d) return 0; let n = 0, k = 0; for (let i = 3; i < d.length; i += 64) { k++; if (d[i] >= 128) n++; } return k ? n / k : 0; };

  let lf = null;
  // Última imagen disponible (explícita, con hora). Si GIBS no acepta horas, cae a "default" con demora estimada.
  function latestFrame(lat, lon) {
    const b = Math.floor(Date.now() / FRAME_MS);
    if (lf && lf.b === b) return lf.p;
    const p = (async () => {
      const [wx, wy] = CT().world(lat, lon), tx = Math.floor(wx / 256), ty = Math.floor(wy / 256);
      for (let k = 2; k <= 7; k++) {
        const t = (b - k) * FRAME_MS;
        if (opaqueFrac(await tile(isoT(t), tx, ty)) >= 0.3) return { t, explicit: true };
      }
      if (opaqueFrac(await tile('default@' + b, tx, ty)) >= 0.3) return { t: Date.now() - 35 * 60000, explicit: false };
      return null;
    })().catch(() => null);
    lf = { b, p };
    return p;
  }

  // Campo de temperatura de topes (°C) en una grilla N×N centrada en el lugar. Fila 0 = sur, columna 0 = oeste.
  async function sampleField(time, lat, lon) {
    const ct = CT(), m = await ct.colormap(), cosL = Math.cos(rad(lat));
    const [x0, y0] = ct.world(lat + HALF / 111, lon - HALF / (111 * cosL));
    const [x1, y1] = ct.world(lat - HALF / 111, lon + HALF / (111 * cosL));
    const data = {}, jobs = [];
    for (let tx = Math.floor(x0 / 256); tx <= Math.floor(x1 / 256); tx++) for (let ty = Math.floor(y0 / 256); ty <= Math.floor(y1 / 256); ty++) {
      jobs.push(tile(time, tx, ty).then(d => { data[tx + '/' + ty] = d; }));
    }
    await Promise.all(jobs);
    const T = new Float32Array(N * N).fill(NaN); let valid = 0;
    for (let iy = 0; iy < N; iy++) for (let ix = 0; ix < N; ix++) {
      const ky = (iy - MID) * STEP, kx = (ix - MID) * STEP;
      const [wx, wy] = ct.world(lat + ky / 111, lon + kx / (111 * cosL));
      const X = Math.floor(wx), Y = Math.floor(wy), d = data[Math.floor(X / 256) + '/' + Math.floor(Y / 256)];
      if (!d) continue;
      const o = ((Y % 256) * 256 + (X % 256)) * 4;
      if (d[o + 3] < 128) continue;
      const v = ct.toC(m, d[o], d[o + 1], d[o + 2]);
      if (v == null) continue;
      T[iy * N + ix] = v; valid++;
    }
    return { T, valid };
  }

  /* ---------- celdas ---------- */
  function findCells(T) {
    const seen = new Uint8Array(N * N), cells = [];
    for (let s = 0; s < N * N; s++) {
      if (seen[s] || !(T[s] <= CELL_C)) continue;
      const q = [s]; seen[s] = 1; let n = 0, sx = 0, sy = 0, mn = 99, cold = 0;
      while (q.length) {
        const i = q.pop(), x = i % N, y = (i - x) / N;
        n++; sx += x; sy += y; if (T[i] < mn) mn = T[i]; if (T[i] <= -52) cold++;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const xx = x + dx, yy = y + dy;
          if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue;
          const j = yy * N + xx;
          if (!seen[j] && T[j] <= CELL_C) { seen[j] = 1; q.push(j); }
        }
      }
      const area = n * STEP * STEP;
      if (n < 2 || area > 20000) continue;      // ruido o banda nubosa extensa (frente / cirros), no una celda
      cells.push({ x: (sx / n - MID) * STEP, y: (sy / n - MID) * STEP, tmin: mn, area, r: Math.max(6, Math.min(35, Math.sqrt(area / Math.PI))), coldFrac: cold / n });
    }
    return cells.sort((a, b) => a.tmin - b.tmin).slice(0, 14);
  }

  /* ---------- movimiento por comparación de imágenes ---------- */
  const inten = T => { const o = new Float32Array(T.length); for (let i = 0; i < T.length; i++) { const v = T[i]; o[i] = v === v ? Math.max(0, Math.min(1, (-35 - v) / 35)) : 0; } return o; };
  function estimateShift(prev, now) {
    let mass = 0; for (let i = 0; i < now.length; i++) mass += now[i];
    if (mass < 10) return null;
    const M = SHIFT_MAX, W = 2 * M + 1, sc = new Float32Array(W * W);
    let best = -1, bi = 0;
    for (let sy = -M; sy <= M; sy++) for (let sx = -M; sx <= M; sx++) {
      let ab = 0, aa = 0, bb = 0;
      const x0 = Math.max(0, sx), x1 = Math.min(N, N + sx), y0 = Math.max(0, sy), y1 = Math.min(N, N + sy);
      for (let y = y0; y < y1; y++) {
        const rn = y * N, rp = (y - sy) * N - sx;
        for (let x = x0; x < x1; x++) { const a = now[rn + x], b = prev[rp + x]; ab += a * b; aa += a * a; bb += b * b; }
      }
      const s = aa > 0 && bb > 0 ? ab / Math.sqrt(aa * bb) : 0;
      sc[(sy + M) * W + (sx + M)] = s;
      if (s > best) { best = s; bi = (sy + M) * W + (sx + M); }
    }
    let bx = bi % W - M, by = Math.floor(bi / W) - M;
    const at = (x, y) => (x < -M || x > M || y < -M || y > M) ? null : sc[(y + M) * W + (x + M)];
    const par = (m1, c, p1) => (m1 == null || p1 == null) ? 0 : (() => { const d = m1 - 2 * c + p1; return d < -1e-6 ? 0.5 * (m1 - p1) / d : 0; })();
    const fx = bx + par(at(bx - 1, by), best, at(bx + 1, by)), fy = by + par(at(bx, by - 1), best, at(bx, by + 1));
    return { sx: fx, sy: fy, q: best };
  }
  async function satMotion(frame, lat, lon, nowT) {
    if (!frame.explicit) return null;
    for (const dtMin of [30, 40, 20]) {
      const pt = frame.t - dtMin * 60000;
      const prev = await sampleField(isoT(pt), lat, lon);
      if (prev.valid < N * N * 0.25) continue;
      const e = estimateShift(inten(prev.T), inten(nowT));
      if (!e) return null;
      const h = dtMin / 60;
      return { u: e.sx * STEP / h, v: e.sy * STEP / h, q: e.q, dtMin };
    }
    return null;
  }

  /* ---------- viento en altura (datos) ---------- */
  const steerCache = new Map();
  async function steering(lat, lon) {
    const key = lat.toFixed(1) + ',' + lon.toFixed(1) + '|' + Math.floor(Date.now() / 1200000);
    if (steerCache.has(key)) return steerCache.get(key);
    const p = (async () => {
      const c = new AbortController(), t = setTimeout(() => c.abort(), 9000);
      try {
        const r = await fetch('https://api.open-meteo.com/v1/forecast?latitude=' + lat.toFixed(3) + '&longitude=' + lon.toFixed(3) +
          '&hourly=wind_speed_700hPa,wind_direction_700hPa,wind_speed_500hPa,wind_direction_500hPa&forecast_hours=2&wind_speed_unit=kmh&timezone=auto', { signal: c.signal });
        if (!r.ok) return null;
        const j = await r.json(), h = j && j.hourly; if (!h) return null;
        let u = 0, v = 0, n = 0;
        [['700', 0.9], ['500', 1.0]].forEach(([lv, f]) => {
          const sp = (h['wind_speed_' + lv + 'hPa'] || [])[0], dr = (h['wind_direction_' + lv + 'hPa'] || [])[0];
          if (sp == null || dr == null) return;
          u += -sp * f * Math.sin(rad(dr)); v += -sp * f * Math.cos(rad(dr)); n++;   // la dirección es "desde dónde sopla"
        });
        return n ? { u: u / n, v: v / n } : null;
      } catch (e) { return null; } finally { clearTimeout(t); }
    })();
    steerCache.set(key, p);
    return p;
  }

  /* ---------- combinar imágenes + datos ---------- */
  const spd = a => Math.hypot(a.u, a.v);
  const hdg = a => (Math.atan2(a.u, a.v) * 180 / Math.PI + 360) % 360;       // hacia dónde va
  const angDiff = (a, b) => { const d = Math.abs(hdg(a) - hdg(b)) % 360; return d > 180 ? 360 - d : d; };
  function combine(sat, mod) {
    const sOk = sat && sat.q >= 0.55 && spd(sat) >= 8;
    const out = { u: 0, v: 0, ok: false, src: '', confirmed: false, q: sat ? sat.q : 0 };
    if (sOk && mod && spd(mod) >= 5) {
      const ang = angDiff(sat, mod), ratio = spd(sat) / Math.max(1, spd(mod));
      if (ang <= 60 && ratio >= 0.4 && ratio <= 2.5) {
        out.u = 0.7 * sat.u + 0.3 * mod.u; out.v = 0.7 * sat.v + 0.3 * mod.v;
        out.ok = true; out.confirmed = true; out.src = 'imágenes de satélite y viento en altura coinciden';
      } else { out.src = 'las imágenes y el viento en altura no coinciden: movimiento dudoso'; }
    } else if (sOk) {
      out.u = sat.u; out.v = sat.v; out.ok = sat.q >= 0.6; out.src = 'solo por imágenes de satélite (sin datos de viento en altura)';
    } else if (mod && spd(mod) >= 8) {
      out.u = mod.u; out.v = mod.v; out.ok = true; out.src = 'solo por viento en altura (sin imágenes comparables)';
    } else { out.src = 'sin movimiento definido'; }
    out.spd = Math.hypot(out.u, out.v); out.dir = hdg(out);
    return out;
  }

  /* ---------- geometría: ¿viene hacia mí? ¿cuándo llega? ---------- */
  function judge(cell, vec, ageH, cfg) {
    const px = cell.x + vec.u * ageH, py = cell.y + vec.v * ageH;           // posición estimada AHORA (km al este / norte)
    const d = Math.hypot(px, py), V2 = vec.u * vec.u + vec.v * vec.v, PV = px * vec.u + py * vec.v;
    const R = cell.r + 3, distEdge = Math.max(0, d - cell.r);
    const o = { px, py, d, distEdge, bearing: (Math.atan2(px, py) * 180 / Math.PI + 360) % 360, hit: false, etaMin: null };
    if (d <= R) { o.hit = true; o.etaMin = 0; return o; }                   // ya está encima
    if (V2 < 64) return o;                                                  // casi quieta (<8 km/h): no se sabe a dónde va
    const tm = -PV / V2;                                                    // h hasta el punto de mayor acercamiento
    if (tm <= 0) return o;                                                  // se aleja
    const miss = Math.hypot(px + vec.u * tm, py + vec.v * tm);
    const disc = PV * PV - V2 * (d * d - R * R);
    if (miss > cell.r + 8 || disc < 0) return o;                            // pasa de largo
    o.hit = true; o.etaMin = Math.max(0, Math.round(60 * (-PV - Math.sqrt(disc)) / V2));
    o.miss = miss;
    return o;
  }

  function evaluate(loc, cells, vec, ageH, cfg, env, tag) {
    const lead = (cfg && cfg.leadMin) || 45, tracks = [], cosL = Math.cos(rad(loc.lat));
    cells.forEach(c => {
      const j = judge(c, vec, ageH, cfg);
      const type = g.stormClass(null, 0, { ctt: c.tmin, cold: c.coldFrac, cape: env && env.cape, lifted_index: env && env.li });
      tracks.push(Object.assign({}, j, {
        type, tmin: c.tmin, r: c.r, area: c.area,
        lat: loc.lat + j.py / 111, lon: loc.lon + j.px / (111 * cosL),
        threat: !!(type && j.hit && vec.ok && (j.distEdge <= NEAR_KM || j.etaMin <= lead)),
        pending: !!(type && j.hit && vec.ok && !(j.distEdge <= NEAR_KM || j.etaMin <= lead) && j.etaMin <= 180)
      }));
    });
    // un evento por tipo (la celda más urgente de cada tipo)
    const events = [], best = {};
    tracks.filter(t => t.type && (t.threat || t.pending)).forEach(t => {
      const b = best[t.type]; if (!b || (t.threat && !b.threat) || (t.threat === b.threat && t.etaMin < b.etaMin)) best[t.type] = t;
    });
    Object.keys(best).forEach(k => {
      const t = best[k], dir = g.bearingName(vec.dir);
      const arrive = t.etaMin === 0 ? 'ya está sobre la zona' : 'llegaría en ~' + t.etaMin + ' min';
      events.push({
        type: k, level: g.RANK[k], place: loc.name, pending: !t.threat, approach: true,
        title: g.TYPES[k].label + ' acercándose',
        detail: 'Celda a ' + Math.round(t.d) + ' km al ' + g.bearingName(t.bearing) + ' (' + (t.tmin <= -65 ? 'muy fuerte' : t.tmin <= -55 ? 'fuerte' : 'moderada') + '), se mueve hacia el ' + dir +
          ' a ' + Math.round(vec.spd) + ' km/h: ' + arrive + '. Rumbo: ' + vec.src + (tag ? ' ' + tag : '') + '.' +
          (t.threat ? '' : ' Te aviso ' + lead + ' min antes de que llegue.')
      });
    });
    return { tracks, events };
  }

  /* ---------- API ---------- */
  const cache = new Map();
  // loc {lat,lon,name}; env {cape, li}. Devuelve {status, events, tracks, vec, frame}. Nunca lanza.
  function assess(loc, cfg, env) {
    const key = loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2) + '|' + Math.floor(Date.now() / 300000) + '|' + ((cfg && cfg.leadMin) || 45) + '|' + (loc.name || '');
    if (cache.size > 30) cache.delete(cache.keys().next().value);
    if (!cache.has(key)) cache.set(key, run(loc, cfg, env || {}).catch(() => ({ status: 'sin-imagenes', events: [], tracks: [], vec: null, frame: null })));
    return cache.get(key);
  }
  async function run(loc, cfg, env) {
    const out = { status: 'sin-imagenes', events: [], tracks: [], vec: null, frame: null };
    if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function' || !CT()) return out;
    const fr = await latestFrame(loc.lat, loc.lon);
    if (!fr) return out;
    const nowF = await sampleField(fr.explicit ? isoT(fr.t) : 'default@' + Math.floor(Date.now() / FRAME_MS), loc.lat, loc.lon);
    if (nowF.valid < N * N * 0.25) return out;
    out.frame = { t: fr.t, explicit: fr.explicit, ageMin: Math.round((Date.now() - fr.t) / 60000) };
    const cells = findCells(nowF.T);
    if (!cells.length) { out.status = 'sin-celdas'; return out; }
    const [sat, mod] = await Promise.all([satMotion(fr, loc.lat, loc.lon, nowF.T).catch(() => null), steering(loc.lat, loc.lon)]);
    const vec = combine(sat, mod);
    out.vec = vec; out.sat = sat; out.mod = mod;
    const ageH = (Date.now() - fr.t) / 3600e3;
    const ev = evaluate(loc, cells, vec, ageH, cfg, env);
    out.tracks = ev.tracks; out.events = vec.ok ? ev.events : [];
    out.status = vec.ok ? 'ok' : 'movimiento-dudoso';
    return out;
  }
  // Respaldo cuando no hay imágenes: celdas que el modelo ve en los anillos de 30/70 km + viento en altura.
  // ring = [{b, k, type}] (rumbo desde el lugar, distancia km, clase de tormenta)
  async function assessRing(loc, ring, cfg, env) {
    try {
      const mod = await steering(loc.lat, loc.lon);
      if (!mod || spd(mod) < 8) return { status: 'sin-datos', events: [], tracks: [], vec: null };
      const vec = combine(null, mod);
      const tm = { hail: -65, stormStrong: -55, stormWeak: -46 };
      const cells = ring.filter(r => r.type).map(r => ({ x: r.k * Math.sin(rad(r.b)), y: r.k * Math.cos(rad(r.b)), tmin: tm[r.type], area: 300, r: 10, coldFrac: r.type === 'hail' ? 0.3 : 0.1 }));
      const ev = evaluate(loc, cells, vec, 0, cfg, env, '(sin imágenes de satélite)');
      return { status: 'ring', events: ev.events, tracks: ev.tracks, vec };
    } catch (e) { return { status: 'sin-datos', events: [], tracks: [], vec: null }; }
  }

  g.Approach = { assess, assessRing, latestFrame, NEAR_KM, _t: { findCells, estimateShift, inten, combine, judge, evaluate, N, STEP, sampleField } };
})(typeof self !== 'undefined' ? self : this);
