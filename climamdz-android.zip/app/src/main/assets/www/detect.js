/* Lógica compartida de detección (la usan index.html y sw.js) */
(function (g) {
  'use strict';
  const ND = ['norte', 'noreste', 'este', 'sudeste', 'sur', 'sudoeste', 'oeste', 'noroeste'];

  g.TYPES = {
    wind:        { icon: '💨', label: 'Viento fuerte',   desc: 'Ráfagas por encima del umbral elegido' },
    zonda:       { icon: '🌬️', label: 'Viento Zonda',    desc: 'Viento seco y cálido del oeste' },
    stormWeak:   { icon: '🌦️', label: 'Tormenta débil',  desc: 'Lluvia o chaparrones leves' },
    stormStrong: { icon: '⛈️', label: 'Tormenta fuerte', desc: 'Lluvia intensa y actividad eléctrica' },
    stormApproach:{ icon: '🌩️', label: 'Tormenta en aproximación', desc: 'Célula observada que se desplaza hacia la ubicación' },
    stormMotion:  { icon: '🛰️', label: 'Movimiento de tormenta observado', desc: 'Desplazamiento medido en imágenes recientes; no implica impacto' },
    hail:        { icon: '🧊', label: 'Tormenta severa / granizo', desc: 'Topes de nube muy fríos o tormenta muy inestable: posible granizo' },
    quake:       { icon: '🏛️', label: 'Sismo',           desc: 'Sismos cercanos' },
    frost:       { icon: '❄️', label: 'Riesgo de helada', desc: 'Temperatura prevista cercana o inferior a 2 °C' }
  };
  g.RANK = { hail: 3, stormApproach: 2.1, stormStrong: 2, stormWeak: 1 };

  // Qué hacer (se muestra en la tarjeta y en la notificación)
  g.TIPS = {
    wind: 'Asegurá objetos sueltos, alejate de árboles, carteles y cables. Evitá rutas expuestas con vehículos altos.',
    zonda: 'Cerrá puertas y ventanas, no hagas fuego, alejate de árboles y cables. Cuidá a personas con problemas respiratorios.',
    stormWeak: 'Reducí la velocidad y encendé luces. No cruces calles anegadas ni zanjones.',
    stormStrong: 'Buscá refugio firme, alejate de ventanas, árboles y cables. No cruces zanjones ni calles anegadas.',
    stormApproach: 'Prepará resguardo, asegurá objetos y seguí los avisos oficiales. La trayectoria estimada puede cambiar.',
    stormMotion: 'Seguí la evolución en el mapa. Que una nube se desplace hacia tu zona no confirma por sí solo lluvia, granizo ni impacto.',
    hail: 'Poné el vehículo bajo techo o refugiate en un lugar cerrado. No te pares bajo árboles. Alejate de ventanas.',
    quake: 'Agachate, cubrite y agarrate junto a un mueble firme. Alejate de ventanas. No uses ascensores.',
    frost: 'Protegé cultivos sensibles y revisá riego antihelada, ventilación y sectores bajos de la finca. La temperatura pronosticada es orientativa; verificá con un sensor local.'
  };

  g.DEFAULT_CFG = {
    notify: { wind: true, zonda: true, stormWeak: false, stormStrong: true, stormApproach: true, stormMotion: false, hail: true, quake: true, frost: true },
    escape: true,
    windKmh: 60, quakeMag: 4, quakeKm: 300, repeatMin: 60, sound: true, vibrate: true, alertLeadMin: 60, frostC: 2
  };
  g.mergeCfg = function (s) {
    s = s || {};
    const d = g.DEFAULT_CFG;
    const out = Object.assign({}, d, s, { notify: Object.assign({}, d.notify, s.notify || {}) });
    delete out.notify.smn;
    return out;
  };

  // Dirección simple para el público: puntos cardinales, nunca grados.
  g.bearingName = b => ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'][Math.round((((Number(b) % 360) + 360) % 360) / 45) % 8];

  // Clasificación de tormenta combinando:
  //  - el modelo (código WMO + lluvia), que suele subestimar las tormentas convectivas,
  //  - la inestabilidad (CAPE / índice de levantamiento) y
  //  - la observación del satélite: temperatura de topes de nube (x.ctt, °C) y fracción de píxeles muy fríos (x.cold).
  g.stormClass = function (code, pr, x) {
    pr = pr || 0; x = x || {};
    const cape = x.cape, li = x.lifted_index, ctt = x.ctt, cold = x.cold || 0;
    const unstable = cape == null || cape >= 300;
    let r = 0;
    // Modelo
    if (code >= 96) r = 3;
    else if (code === 95 && cape >= 2000 && (li == null || li <= -5)) r = 3;
    else if (code === 95 || code === 82 || pr >= 4) r = 2;
    else if ((code === 80 || code === 81 || code === 65) && cape >= 1000 && (li == null || li <= -3)) r = 2;
    else if ((code >= 51 && code <= 67) || code === 80 || code === 81 || pr >= 0.2) r = 1;
    // Satélite (observado)
    if (ctt != null) {
      let s = 0;
      if (ctt <= -70 && cold >= 0.25 && unstable) s = 3;            // topes extremadamente fríos: tormenta severa
      else if (ctt <= -62 && cold >= 0.2 && cape >= 1500) s = 3;
      else if (ctt <= -52 && cold >= 0.1 && (unstable || r)) s = 2;  // convección profunda
      else if (ctt <= -40 && (r || cape >= 500)) s = 1;
      if (s > r) r = s;
    }
    return r === 3 ? 'hail' : r === 2 ? 'stormStrong' : r === 1 ? 'stormWeak' : null;
  };

  // Texto con los datos que respaldan la clasificación
  g.stormWhy = function (x) {
    x = x || {};
    const p = [];
    if (x.ctt != null && x.ctt <= -40) p.push('satélite: topes de nube a ' + Math.round(x.ctt) + ' °C' + (x.ctt <= -65 ? ' (muy altos)' : ''));
    if (x.cape >= 500) p.push('atmósfera inestable');
    if (x.wind_speed_10m != null) p.push('viento ' + Math.round(x.wind_speed_10m) + ' km/h del ' + g.bearingName(x.wind_direction_10m || 0) + (x.wind_gusts_10m != null ? ', ráfagas ' + Math.round(x.wind_gusts_10m) + ' km/h' : ''));
    return p.length ? ' (' + p.join(', ') + ')' : '';
  };


  const when = minutes => (minutes <= 0 ? 'ahora' : 'en ~' + minutes + ' min');

  // Eventos para un punto: c = current, h = hourly (próximas 6 h), place = nombre del lugar
  g.detectPoint = function (c, h, cfg, place) {
    const ev = [];
    h = h || {};
    const first = {};
    const consider = (k, hr) => { if (k && (first[k] === undefined || hr < first[k])) first[k] = hr; };
    consider(g.stormClass(c.weather_code, c.precipitation, c), 0);
    const lead = Math.max(30, Math.min(90, Number(cfg.alertLeadMin) || 60));
    const m15 = h.minutely_15 || {};
    if ((m15.weather_code || []).length) {
      (m15.weather_code || []).forEach((w, i) => {
        const minutes = (i + 1) * 15;
        if (minutes >= 30 && minutes <= lead) consider(g.stormClass(w, (m15.precipitation || [])[i] || 0,
          { cape: (m15.cape || [])[i] }), minutes);
      });
    } else {
      (h.weather_code || []).forEach((w, i) => {
        const minutes = i * 60;
        if (minutes >= 30 && minutes <= lead) consider(g.stormClass(w, (h.precipitation || [])[i] || 0,
          { cape: (h.cape || [])[i], lifted_index: (h.lifted_index || [])[i] }), minutes);
      });
    }
    // Riesgo de helada: temperatura actual o prevista dentro de la ventana elegida.
    const frostLimit = Number.isFinite(Number(cfg.frostC)) ? Number(cfg.frostC) : 2;
    let frostAt = c.temperature_2m != null && c.temperature_2m <= frostLimit ? 0 : null;
    const frostSeries = (m15.temperature_2m || []).length ? m15.temperature_2m : (h.temperature_2m || []);
    frostSeries.forEach((v, i) => {
      const minutes = (m15.temperature_2m && m15.temperature_2m.length) ? (i + 1) * 15 : i * 60;
      if (v != null && v <= frostLimit && minutes >= 30 && minutes <= lead && (frostAt === null || minutes < frostAt)) frostAt = minutes;
    });
    if (frostAt !== null) ev.push({ type: 'frost', level: frostAt === 0 ? 3 : 2, title: 'Riesgo de helada', place: place,
      detail: 'Temperatura ' + (frostAt === 0 ? 'actual' : 'prevista en ~' + frostAt + ' min') + ' de ' + Math.round(frostAt === 0 ? c.temperature_2m : frostSeries[(m15.temperature_2m && m15.temperature_2m.length) ? Math.max(0, Math.round(frostAt / 15) - 1) : frostAt / 60]) + ' °C. Umbral de aviso: ' + frostLimit + ' °C.' });

    const txt = { hail: 'Tormenta severa con posible granizo ', stormStrong: 'Tormenta fuerte con lluvia intensa y rayos ', stormWeak: 'Lluvia o tormenta débil ' };
    Object.keys(first).forEach(k => ev.push({
      type: k, level: g.RANK[k], title: g.TYPES[k].label, place: place,
      detail: txt[k] + when(first[k]) + (first[k] === 0 ? g.stormWhy(c) : '') + '.'
    }));

    let gust = c.wind_gusts_10m || 0;
    const gustSeries=(m15.wind_gusts_10m||[]).length?m15.wind_gusts_10m:(h.wind_gusts_10m||[]);
    gustSeries.forEach((v,i)=>{const minutes=(m15.wind_gusts_10m||[]).length?(i+1)*15:i*60;if(minutes<=lead&&v>gust)gust=v;});
    if (gust >= cfg.windKmh) {
      const level = gust >= cfg.windKmh + 40 ? 3 : gust >= cfg.windKmh + 20 ? 2 : 1;
      ev.push({ type: 'wind', level, title: 'Viento fuerte', place: place,
        detail: 'Ráfagas de hasta ' + Math.round(gust) + ' km/h dentro de la anticipación seleccionada.' +
          (c.wind_direction_10m != null ? ' Viento del ' + g.bearingName(c.wind_direction_10m) + '.' : '') });
    }
    // Zonda nunca se infiere solo por viento del oeste, calor o baja humedad.
    // Se agrega únicamente cuando un aviso oficial del SMN cubre este punto.
    return ev;
  };

  // ---- Clima con varias fuentes (todas se piden directo desde el celular, sin servidor propio) ----
  // Orden: Open-Meteo -> MET Norway -> wttr.in -> (opcional) servidor propio si g.WEATHER_API está definido.
  // Si una alcanza su límite o falla, se pasa a la siguiente y se la deja "en pausa" un rato.
  // Devuelve un array [{current, hourly}] en formato Open-Meteo.
  const CUR_FULL = 'temperature_2m,relative_humidity_2m,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,cape,lifted_index';
  const BLK = 'wxBlock';
  let blocks = {};
  try { blocks = JSON.parse((g.localStorage && g.localStorage.getItem(BLK)) || '{}') || {}; } catch (e) {}
  const isBlocked = n => (blocks[n] || 0) > Date.now();
  function setBlock(n, ms) {
    blocks[n] = Date.now() + ms;
    try { g.localStorage && g.localStorage.setItem(BLK, JSON.stringify(blocks)); } catch (e) {}
  }
  const untilMidnight = () => { const d = new Date(); d.setUTCHours(24, 0, 0, 0); return d - Date.now(); };
  async function getJ(url, ms) {
    const c = new AbortController(), t = setTimeout(() => c.abort(), ms);
    try {
      const r = await fetch(url, { signal: c.signal });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!r.ok || (j && j.error)) {
        const err = new Error((j && j.reason) || ('HTTP ' + r.status));
        err.limit = r.status === 429 || /limit/i.test(err.message);
        throw err;
      }
      return j;
    } finally { clearTimeout(t); }
  }

  // 1) Open-Meteo
  async function runOpenMeteo(pts, full, hourly, ms) {
    const u = 'https://api.open-meteo.com/v1/forecast?latitude=' + pts.map(p => (+p[0]).toFixed(3)).join(',') +
      '&longitude=' + pts.map(p => (+p[1]).toFixed(3)).join(',') +
      '&current=' + (full ? CUR_FULL : 'weather_code,precipitation,cape,lifted_index,wind_speed_10m,wind_direction_10m') +
      (hourly ? '&hourly=temperature_2m,weather_code,precipitation,wind_gusts_10m,wind_speed_10m,wind_direction_10m,cape,lifted_index,wind_speed_700hPa,wind_direction_700hPa,wind_speed_500hPa,wind_direction_500hPa&forecast_hours=6&minutely_15=temperature_2m,weather_code,precipitation,wind_gusts_10m,cape&forecast_minutely_15=8' : '') + '&timezone=auto&wind_speed_unit=kmh';
    const j = await getJ(u, ms);
    return (Array.isArray(j) ? j : [j]).map(d => ({ current: d.current, hourly: d.hourly, minutely_15: d.minutely_15 }));
  }

  // 2) MET Norway (yr.no)
  function metToWmo(s, pr) {
    s = (s || '').replace(/_(day|night|polartwilight)$/, '');
    if (/thunder/.test(s)) return 95;
    if (/sleet/.test(s)) return /heavy/.test(s) ? 67 : 66;
    if (/snow/.test(s)) return /heavy/.test(s) ? 75 : /light/.test(s) ? 71 : 73;
    if (/rainshowers/.test(s)) return /heavy/.test(s) ? 82 : /light/.test(s) ? 80 : 81;
    if (/rain/.test(s)) return /heavy/.test(s) ? 65 : /light/.test(s) ? 61 : 63;
    if (s === 'fog') return 45;
    if (s === 'cloudy') return 3;
    if (s === 'partlycloudy') return 2;
    if (s === 'fair') return 1;
    if (s === 'clearsky') return 0;
    return pr >= 0.2 ? 61 : 0;
  }
  async function metOne(lat, lon, ms) {
    const j = await getJ('https://api.met.no/weatherapi/locationforecast/2.0/complete?lat=' + (+lat).toFixed(4) + '&lon=' + (+lon).toFixed(4), ms);
    const ts = (j && j.properties && j.properties.timeseries) || [];
    if (!ts.length) throw new Error('MET sin datos');
    const now = Date.now();
    let i0 = ts.findIndex(t => Date.parse(t.time) + 3600e3 > now);
    if (i0 < 0) i0 = 0;
    const conv = t => {
      const d = t.data.instant.details, n = t.data.next_1_hours || t.data.next_6_hours || {};
      const pr = (n.details && n.details.precipitation_amount) || 0;
      return {
        temperature_2m: d.air_temperature,
        relative_humidity_2m: Math.round(d.relative_humidity),
        precipitation: pr,
        weather_code: metToWmo(n.summary && n.summary.symbol_code, pr),
        cloud_cover: Math.round(d.cloud_area_fraction),
        wind_speed_10m: Math.round(d.wind_speed * 3.6 * 10) / 10,
        wind_direction_10m: Math.round(d.wind_from_direction),
        wind_gusts_10m: Math.round((d.wind_speed_of_gust != null ? d.wind_speed_of_gust : d.wind_speed * 1.5) * 3.6 * 10) / 10
      };
    };
    const hrs = ts.slice(i0, i0 + 6).map(conv);
    return {
      current: hrs[0],
      hourly: { temperature_2m: hrs.map(h => h.temperature_2m), weather_code: hrs.map(h => h.weather_code), precipitation: hrs.map(h => h.precipitation), wind_gusts_10m: hrs.map(h => h.wind_gusts_10m) }
    };
  }
  const runMet = (pts, full, hourly, ms) => Promise.all(pts.map(p => metOne(p[0], p[1], ms)));

  // 3) wttr.in
  function wwoToWmo(c) {
    c = +c;
    if ([200, 386, 389, 392, 395].includes(c)) return 95;
    if (c === 113) return 0;
    if (c === 116) return 2;
    if (c === 119 || c === 122) return 3;
    if ([143, 248, 260].includes(c)) return 45;
    if (c === 176 || c === 353) return 80;
    if (c === 356) return 81;
    if (c === 359) return 82;
    if ([263, 266, 293, 296].includes(c)) return 61;
    if (c === 299 || c === 302) return 63;
    if (c === 305 || c === 308) return 65;
    if ([182, 185, 281, 284, 311, 314, 317, 320, 350, 362, 365, 374, 377].includes(c)) return 66;
    if ([179, 227, 230, 323, 326, 329, 332, 335, 338, 368, 371].includes(c)) return 73;
    return 0;
  }
  async function wttrOne(lat, lon, ms) {
    const j = await getJ('https://wttr.in/' + (+lat).toFixed(3) + ',' + (+lon).toFixed(3) + '?format=j1', ms);
    const c = j && j.current_condition && j.current_condition[0];
    if (!c) throw new Error('wttr sin datos');
    const current = {
      temperature_2m: +c.temp_C, relative_humidity_2m: +c.humidity, precipitation: +c.precipMM || 0,
      weather_code: wwoToWmo(c.weatherCode), cloud_cover: +c.cloudcover,
      wind_speed_10m: +c.windspeedKmph, wind_direction_10m: +c.winddirDegree, wind_gusts_10m: +c.windspeedKmph * 1.5
    };
    const slots = [];
    (j.weather || []).forEach(d => (d.hourly || []).forEach(h => {
      slots.push({ t: Date.parse(d.date + 'T00:00:00Z') + (+h.time / 100) * 3600e3, h });
    }));
    const m = /(\d{4}-\d{2}-\d{2}) (\d{1,2}):(\d{2}) (AM|PM)/.exec(c.localObsDateTime || '');
    let nowLocal = Date.now();
    if (m) { let hh = +m[2] % 12; if (m[4] === 'PM') hh += 12; nowLocal = Date.parse(m[1] + 'T00:00:00Z') + hh * 3600e3 + +m[3] * 60e3; }
    const H = { temperature_2m: [], weather_code: [], precipitation: [], wind_gusts_10m: [] };
    for (let i = 0; i < 6; i++) {
      const t = nowLocal + i * 3600e3;
      const s = slots.filter(x => x.t <= t).pop() || slots[0];
      if (!s) break;
      H.temperature_2m.push(Number.isFinite(+s.h.tempC) ? +s.h.tempC : null);
      H.weather_code.push(wwoToWmo(s.h.weatherCode));
      H.precipitation.push((+s.h.precipMM || 0) / 3);
      H.wind_gusts_10m.push(+s.h.WindGustKmph || 0);
    }
    if (H.wind_gusts_10m.length) current.wind_gusts_10m = Math.max(current.wind_speed_10m, H.wind_gusts_10m[0]);
    return { current, hourly: H };
  }
  const runWttr = (pts, full, hourly, ms) => Promise.all(pts.map(p => wttrOne(p[0], p[1], ms)));

  // 4) Servidor propio (opcional): definir window.WEATHER_API = 'https://tu-sitio.netlify.app' para usarlo
  async function runServer(pts, full, hourly, ms) {
    const base = (g.WEATHER_API || '').replace(/\/$/, '');
    const u = base + '/api/weather?lat=' + pts.map(p => (+p[0]).toFixed(2)).join(',') + '&lon=' + pts.map(p => (+p[1]).toFixed(2)).join(',') +
      '&full=' + (full ? 1 : 0) + '&hourly=' + (hourly ? 1 : 0);
    const r = await getJ(u, ms + 10000);
    return r.data;
  }

  const PROVIDERS = [
    { name: 'open-meteo', label: 'Open-Meteo', max: 50, run: runOpenMeteo },
    { name: 'met-norway', label: 'MET Norway', max: 24, run: runMet },
    { name: 'wttr', label: 'wttr.in', max: 12, run: runWttr },
    { name: 'servidor', label: 'Servidor propio', max: 50, run: runServer, enabled: () => !!g.WEATHER_API }
  ];

  g.weatherSource = '';
  g.fetchWeather = async function (pts, opts) {
    opts = opts || {};
    const full = opts.full !== false, hourly = !!opts.hourly, ms = opts.timeout || 8000;
    const errors = []; let allLimit = true, tried = 0;
    for (const p of PROVIDERS) {
      if (p.enabled && !p.enabled()) continue;
      if (pts.length > p.max) continue;
      if (isBlocked(p.name)) { errors.push(p.label + ': en pausa por límite'); continue; }
      tried++;
      try {
        const data = await p.run(pts, full, hourly, ms);
        if (!data || !data.length || !data.every(d => d && d.current)) throw new Error('respuesta sin datos');
        g.weatherSource = p.label;
        return data;
      } catch (e) {
        const msg = (e && e.name === 'AbortError') ? 'tiempo agotado' : ((e && e.message) || 'error');
        if (e && e.limit) setBlock(p.name, /minut/i.test(msg) ? 60e3 : /hour/i.test(msg) ? 3600e3 : p.name === 'open-meteo' ? untilMidnight() : 900e3);
        else allLimit = false;
        errors.push(p.label + ': ' + msg);
      }
    }
    const err = new Error('Ningún proveedor respondió (' + (errors.join(' | ') || 'sin proveedores disponibles') + ')');
    err.limit = allLimit && tried > 0;
    throw err;
  };

  // ---- Satélite: temperatura de topes de nube (observado, GOES-East, NASA GIBS) ----
  // Se calcula directo en el celular: baja los mosaicos del satélite, los lee y busca el punto más frío
  // en ~10 km a la redonda. Devuelve [{min, cold}] por punto, o null si no hay datos. Nunca lanza error.
  const CT_LAYER = 'GOES-East_ABI_Band13_Clean_Infrared', CT_Z = 6, CT_TS = 256;
  const CT_CMAP = 'https://gibs.earthdata.nasa.gov/colormaps/v1.3/Clean_Longwave_Infrared_Window_Band.xml';
  let ctMap = null;
  async function ctColormap() {
    if (ctMap) return ctMap;
    const c = new AbortController(), t = setTimeout(() => c.abort(), 8000);
    try {
      const r = await fetch(CT_CMAP, { signal: c.signal });
      if (!r.ok) throw new Error('colormap HTTP ' + r.status);
      const xml = await r.text();
      const m = new Map(); const re = /rgb="(\d+),(\d+),(\d+)"[^>]*?value="\(([-+\d.INF]+),([-+\d.INF]+)\]"/g; let x;
      while ((x = re.exec(xml))) {
        const a = parseFloat(x[4]), b = parseFloat(x[5]);
        const v = isFinite(a) && isFinite(b) ? (a + b) / 2 : isFinite(a) ? a : b;
        const k = x[1] + ',' + x[2] + ',' + x[3];
        if (!m.has(k)) m.set(k, v);
      }
      if (m.size < 50) throw new Error('colormap inválido');
      return (ctMap = m);
    } finally { clearTimeout(t); }
  }
  function ctColorToC(m, r, gg, b) {
    const k = r + ',' + gg + ',' + b;
    if (m.has(k)) return m.get(k);
    let best = null, bd = 1e9;
    for (const [kk, v] of m) {
      const c = kk.split(','), d = (c[0] - r) ** 2 + (c[1] - gg) ** 2 + (c[2] - b) ** 2;
      if (d < bd) { bd = d; best = v; }
    }
    const val = bd <= 300 ? best : null;
    m.set(k, val);
    return val;
  }
  const ctWorld = (lat, lon) => {
    const n = CT_TS * 2 ** CT_Z, s = Math.sin(lat * Math.PI / 180);
    return [(lon + 180) / 360 * n, (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * n];
  };
  let ctTiles = new Map(), ctBucket = 0;
  function ctTile(tx, ty) {
    const bk = Math.floor(Date.now() / 600000);
    if (bk !== ctBucket) { ctBucket = bk; ctTiles = new Map(); }
    const k = tx + '/' + ty;
    if (!ctTiles.has(k)) ctTiles.set(k, (async () => {
      const c = new AbortController(), t = setTimeout(() => c.abort(), 10000);
      try {
        const u = 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/' + CT_LAYER + '/default/default/GoogleMapsCompatible_Level6/' + CT_Z + '/' + ty + '/' + tx + '.png';
        const r = await fetch(u, { signal: c.signal });
        if (!r.ok) throw new Error('tile HTTP ' + r.status);
        const bmp = await createImageBitmap(await r.blob());
        const cv = new OffscreenCanvas(bmp.width, bmp.height), cx = cv.getContext('2d', { willReadFrequently: true });
        cx.drawImage(bmp, 0, 0);
        return cx.getImageData(0, 0, bmp.width, bmp.height).data;
      } finally { clearTimeout(t); }
    })().catch(() => null));
    return ctTiles.get(k);
  }
  g.fetchCloudTops = async function (pts) {
    try {
      if (g.WEATHER_API) {
        const u = g.WEATHER_API.replace(/\/$/, '') + '/api/cloudtops?lat=' + pts.map(p => (+p[0]).toFixed(2)).join(',') + '&lon=' + pts.map(p => (+p[1]).toFixed(2)).join(',');
        const r = await getJ(u, 12000);
        if (Array.isArray(r && r.data)) return r.data;
      }
      if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function' || pts.length > 40) return null;
      const m = await ctColormap();
      const out = await Promise.all(pts.map(async ([lat, lon]) => {
        const [wx, wy] = ctWorld(lat, lon);
        const kmPerPx = 40075 * Math.cos(lat * Math.PI / 180) / (CT_TS * 2 ** CT_Z);
        const R = Math.max(2, Math.round(10 / kmPerPx));
        let min = Infinity, n = 0, cold = 0;
        for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
          if (dx * dx + dy * dy > R * R) continue;
          const X = Math.floor(wx) + dx, Y = Math.floor(wy) + dy;
          const d = await ctTile(Math.floor(X / CT_TS), Math.floor(Y / CT_TS));
          if (!d) continue;
          const o = ((((Y % CT_TS) + CT_TS) % CT_TS) * CT_TS + (((X % CT_TS) + CT_TS) % CT_TS)) * 4;
          if (d[o + 3] < 128) continue;
          const v = ctColorToC(m, d[o], d[o + 1], d[o + 2]);
          if (v == null) continue;
          n++; if (v < min) min = v; if (v <= -52) cold++;
        }
        return n ? { min: Math.round(min * 10) / 10, cold: Math.round(cold / n * 100) / 100 } : null;
      }));
      return out.some(Boolean) ? out : null;
    } catch (e) { return null; }
  };
  // Agrega ctt/cold a cada "current" (arr en formato [{current}])
  g.attachCloudTops = function (arr, ct) {
    if (!arr || !ct) return arr;
    arr.forEach((d, i) => { const t = ct[i]; if (d && d.current && t) { d.current.ctt = t.min; d.current.cold = t.cold; } });
    return arr;
  };

  // ---- Movimiento de nubosidad convectiva GOES IR (NASA GIBS, secuencia histórica) ----
  // Compara cinco imágenes IR subdiarias. Es seguimiento de rasgos nubosos, no el producto
  // oficial DMW NetCDF: se usa como segunda observación independiente del radar.
  const goesMotionCache = new Map(), goesMotionTileCache = new Map();
  const GOES_MOTION_Z = 6, GOES_MOTION_RADIUS_KM = 180, GOES_MOTION_STEP = 2;
  async function goesMotionTile(tx, ty, isoTime) {
    const key = tx + '/' + ty + '/' + isoTime;
    if (goesMotionTileCache.has(key)) return goesMotionTileCache.get(key);
    const promise = (async () => {
      const ac = new AbortController(), timer = setTimeout(() => ac.abort(), 10000);
      try {
        const url = 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/' + CT_LAYER + '/default/' +
          encodeURIComponent(isoTime) + '/GoogleMapsCompatible_Level6/' + GOES_MOTION_Z + '/' + ty + '/' + tx + '.png';
        const r = await fetch(url, { signal: ac.signal, mode: 'cors', cache: 'force-cache' });
        if (!r.ok) throw new Error('GOES IR histórico HTTP ' + r.status);
        if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function') throw new Error('lectura de imagen GOES no disponible');
        const bmp = await createImageBitmap(await r.blob());
        const cv = new OffscreenCanvas(bmp.width, bmp.height), cx = cv.getContext('2d', { willReadFrequently: true });
        cx.drawImage(bmp, 0, 0);
        return { data: cx.getImageData(0, 0, bmp.width, bmp.height).data, width: bmp.width, height: bmp.height };
      } finally { clearTimeout(timer); }
    })().catch(e => { goesMotionTileCache.delete(key); throw e; });
    goesMotionTileCache.set(key, promise);
    while (goesMotionTileCache.size > 72) goesMotionTileCache.delete(goesMotionTileCache.keys().next().value);
    return promise;
  }
  async function goesColdComponents(loc, isoTime, cmap) {
    const world = ctWorld(+loc.lat, +loc.lon), kmPx = 40075.017 * Math.cos(+loc.lat * Math.PI / 180) / (256 * Math.pow(2, GOES_MOTION_Z));
    const radius = Math.ceil(GOES_MOTION_RADIUS_KM / kmPx), half = Math.ceil(radius / GOES_MOTION_STEP);
    const tiles = new Map(), minTX = Math.floor((world[0] - radius) / 256), maxTX = Math.floor((world[0] + radius) / 256);
    const minTY = Math.floor((world[1] - radius) / 256), maxTY = Math.floor((world[1] + radius) / 256);
    const req = [];
    for (let ty = minTY; ty <= maxTY; ty++) for (let tx = minTX; tx <= maxTX; tx++) req.push([tx, ty]);
    const loaded = await Promise.all(req.map(async ([tx, ty]) => [tx + '/' + ty, await goesMotionTile(tx, ty, isoTime)]));
    loaded.forEach(([k, v]) => { if (v) tiles.set(k, v); });
    const width = half * 2 + 1, n = width * width, mask = new Uint8Array(n), temps = new Float32Array(n);
    for (let gy = 0; gy < width; gy++) for (let gx = 0; gx < width; gx++) {
      const dx = (gx - half) * GOES_MOTION_STEP, dy = (gy - half) * GOES_MOTION_STEP;
      if (dx * dx + dy * dy > radius * radius) continue;
      const wx = Math.floor(world[0]) + dx, wy = Math.floor(world[1]) + dy;
      const tx = Math.floor(wx / 256), ty = Math.floor(wy / 256), tile = tiles.get(tx + '/' + ty);
      if (!tile || wx < 0 || wy < 0) continue;
      const px = ((wx % 256) + 256) % 256, py = ((wy % 256) + 256) % 256;
      if (px >= tile.width || py >= tile.height) continue;
      const o = (py * tile.width + px) * 4;
      if (tile.data[o + 3] < 128) continue;
      const temp = ctColorToC(cmap, tile.data[o], tile.data[o + 1], tile.data[o + 2]);
      if (temp == null) continue;
      const k = gy * width + gx; temps[k] = temp;
      // -50 °C: filtra nubosidad convectiva profunda y reduce el seguimiento de cirros cálidos.
      if (temp <= -50) mask[k] = 1;
    }
    const seen = new Uint8Array(n), queue = new Int32Array(n), comps = [];
    for (let seed = 0; seed < n; seed++) {
      if (!mask[seed] || seen[seed]) continue;
      let head = 0, tail = 0, count = 0, sx = 0, sy = 0, min = Infinity, sum = 0;
      queue[tail++] = seed; seen[seed] = 1;
      while (head < tail) {
        const k = queue[head++], x = k % width, y = (k / width) | 0, t = temps[k];
        count++; sx += x; sy += y; min = Math.min(min, t); sum += t;
        const nb = [x > 0 ? k - 1 : -1, x + 1 < width ? k + 1 : -1, y > 0 ? k - width : -1, y + 1 < width ? k + width : -1];
        for (const q of nb) if (q >= 0 && mask[q] && !seen[q]) { seen[q] = 1; queue[tail++] = q; }
      }
      if (count >= 4) {
        const px = (sx / count - half) * GOES_MOTION_STEP, py = (sy / count - half) * GOES_MOTION_STEP;
        comps.push({ x: px * kmPx, y: -py * kmPx, area: count, minC: Math.round(min * 10) / 10, meanC: Math.round(sum / count * 10) / 10 });
      }
    }
    return comps;
  }
  g.trackGoesCloudMotion = async function (loc, target) {
    try {
      if (!loc || !Number.isFinite(+loc.lat) || !Number.isFinite(+loc.lon)) return { available: false, reason: 'Ubicación no válida.' };
      const now = Date.now(), newest = Math.floor((now - 18 * 60000) / 600000) * 600000;
      const times = [4, 3, 2, 1, 0].map(i => newest - i * 600000);
      const cacheKey = (+loc.lat).toFixed(3) + ',' + (+loc.lon).toFixed(3) + ':' + times[4];
      const cached = goesMotionCache.get(cacheKey);
      if (cached && now - cached.at < 7 * 60000) return cached.value;
      const cmap = await ctColormap();
      const samples = await Promise.all(times.map(async t => {
        const iso = new Date(t).toISOString().replace(/\.000Z$/, 'Z');
        try { return { time: t / 1000, comps: await goesColdComponents(loc, iso, cmap) }; }
        catch (e) { return { time: t / 1000, comps: [], error: (e && e.message) || 'GOES sin datos' }; }
      }));
      const lastSample = samples[samples.length - 1];
      if (!lastSample || !lastSample.comps.length) return { available: false, reason: 'GOES IR histórico sin píxeles convectivos analizables en esta ubicación.' };
      const tx = target && Number.isFinite(+target.x) ? +target.x : 0, ty = target && Number.isFinite(+target.y) ? +target.y : 0;
      const candidates = lastSample.comps.slice().sort((a, b) => Math.hypot(a.x - tx, a.y - ty) - Math.hypot(b.x - tx, b.y - ty)).slice(0, 5), fits = [];
      for (const seed of candidates) {
        const reverse = [{ time: lastSample.time, x: seed.x, y: seed.y, area: seed.area, minC: seed.minC }];
        let next = seed, nextTime = lastSample.time;
        for (let i = samples.length - 2; i >= 0; i--) {
          const sample = samples[i]; if (!sample.comps.length) continue;
          const dt = Math.max(1, (nextTime - sample.time) / 60), maxJump = Math.min(160, 40 + dt * 0.20);
          let best = null, bestD = Infinity;
          for (const c of sample.comps) { const d = Math.hypot(c.x - next.x, c.y - next.y); if (d < bestD) { bestD = d; best = c; } }
          if (best && bestD <= maxJump) { reverse.push({ time: sample.time, x: best.x, y: best.y, area: best.area, minC: best.minC }); next = best; nextTime = sample.time; }
        }
        const points = reverse.reverse(), fit = fitRadarTrack(points);
        if (fit) { fit.cloudTopMinC = Math.min(...points.map(p => p.minC)); fits.push(fit); }
      }
      if (!fits.length) return { available: false, detected: true, reason: 'GOES detecta topes fríos, pero no hay suficientes imágenes coherentes para medir su desplazamiento.' };
      fits.sort((a, b) => { const da = target ? Math.hypot(a.latestX - tx, a.latestY - ty) : a.distanceKm; const db = target ? Math.hypot(b.latestX - tx, b.latestY - ty) : b.distanceKm; return da - db || (a.approaching === b.approaching ? 0 : a.approaching ? -1 : 1); });
      const fit = fits[0]; fit.available = true; fit.detected = true; fit.source = 'GOES IR NASA GIBS';
      fit.cellLat = +loc.lat + fit.latestY / 111.32;
      fit.cellLon = +loc.lon + fit.latestX / (111.32 * Math.cos(+loc.lat * Math.PI / 180));
      fit.sampleCount = fit.points.length; fit.windowMin = fit.observedMin;
      goesMotionCache.set(cacheKey, { at: now, value: fit });
      while (goesMotionCache.size > 30) goesMotionCache.delete(goesMotionCache.keys().next().value);
      return fit;
    } catch (e) { return { available: false, reason: 'No se pudo analizar la secuencia GOES: ' + ((e && e.message) || 'error') }; }
  };
  // Timeline público de RainViewer (solo imágenes pasadas; no se usa como nowcast).
  g.fetchRadarTimeline = async function () {
    const j = await getJ('https://api.rainviewer.com/public/weather-maps.json', 10000);
    const past = j && j.radar && j.radar.past;
    if (!Array.isArray(past) || past.length < 4) throw new Error('RainViewer no entregó cuatro imágenes históricas utilizables.');
    return { host: j.host || 'https://tilecache.rainviewer.com', frames: past.slice(-5) };
  };
  // Exportación pequeña para pruebas automatizadas de ajuste de trayectoria.
  g.fitObservedMotion = fitRadarTrack;

  // ---- Seguimiento de células convectivas por radar (RainViewer) ----
  // Mide el movimiento observado entre imágenes pasadas. No usa el viento de superficie
  // como velocidad de la tormenta. Requiere imágenes consecutivas y cobertura de radar.
  const RADAR_Z = 7, RADAR_SIZE = 512, RADAR_GRID = 128, RADAR_STEP = 4;
  const radarTileCache = new Map(), radarTrackCache = new Map();
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const mercatorPx = (lat, lon, z) => {
    const n = 256 * Math.pow(2, z), s = clamp(Math.sin(lat * Math.PI / 180), -0.9999, 0.9999);
    return { x: (lon + 180) / 360 * n, y: (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * n };
  };
  const radarPixelKm = lat => 40075.017 * Math.cos(lat * Math.PI / 180) / (256 * Math.pow(2, RADAR_Z));
  async function radarBitmap(url) {
    if (radarTileCache.has(url)) return radarTileCache.get(url);
    const promise = (async () => {
      const ac = new AbortController(), timer = setTimeout(() => ac.abort(), 9000);
      try {
        const r = await fetch(url, { signal: ac.signal, mode: 'cors', cache: 'force-cache' });
        if (!r.ok) throw new Error('radar HTTP ' + r.status);
        const blob = await r.blob();
        if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas !== 'function') throw new Error('lectura de imagen no disponible');
        const bmp = await createImageBitmap(blob);
        const cv = new OffscreenCanvas(bmp.width, bmp.height), cx = cv.getContext('2d', { willReadFrequently: true });
        cx.drawImage(bmp, 0, 0);
        return { data: cx.getImageData(0, 0, bmp.width, bmp.height).data, width: bmp.width, height: bmp.height };
      } finally { clearTimeout(timer); }
    })().catch(e => { radarTileCache.delete(url); throw e; });
    radarTileCache.set(url, promise);
    while (radarTileCache.size > 90) radarTileCache.delete(radarTileCache.keys().next().value);
    return promise;
  }
  function radarEchoComponents(image, lat) {
    const w = image.width, h = image.height, data = image.data, n = RADAR_GRID * RADAR_GRID;
    const mask = new Uint8Array(n), weights = new Float32Array(n), step = RADAR_STEP;
    const center = RADAR_SIZE / 2, kmPx = radarPixelKm(lat), maxR = 185 / kmPx;
    for (let gy = 0; gy < RADAR_GRID; gy++) for (let gx = 0; gx < RADAR_GRID; gx++) {
      const px = gx * step + 2, py = gy * step + 2;
      const dx = px - center, dy = py - center;
      if (dx * dx + dy * dy > maxR * maxR) continue;
      const o = (py * w + px) * 4, r = data[o], gg = data[o + 1], b = data[o + 2], a = data[o + 3];
      if (a < 78) continue;
      const mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), sat = mx ? (mx - mn) / mx : 0;
      const brightSnow = a > 235 && mn > 190;
      if (sat < 0.22 && !brightSnow) continue;
      const k = gy * RADAR_GRID + gx;
      mask[k] = 1; weights[k] = Math.max(0.2, a / 255) * (brightSnow ? 1.3 : 1);
    }
    const seen = new Uint8Array(n), queue = new Int32Array(n), comps = [];
    for (let seed = 0; seed < n; seed++) {
      if (!mask[seed] || seen[seed]) continue;
      let head = 0, tail = 0, count = 0, sx = 0, sy = 0, sw = 0;
      queue[tail++] = seed; seen[seed] = 1;
      while (head < tail) {
        const k = queue[head++], x = k % RADAR_GRID, y = (k / RADAR_GRID) | 0, wt = weights[k];
        count++; sx += (x * step + 2) * wt; sy += (y * step + 2) * wt; sw += wt;
        const nb = [x > 0 ? k - 1 : -1, x + 1 < RADAR_GRID ? k + 1 : -1, y > 0 ? k - RADAR_GRID : -1, y + 1 < RADAR_GRID ? k + RADAR_GRID : -1];
        for (const q of nb) if (q >= 0 && mask[q] && !seen[q]) { seen[q] = 1; queue[tail++] = q; }
      }
      if (count >= 3 && sw > 0) {
        const px = sx / sw, py = sy / sw;
        comps.push({ x: (px - center) * kmPx, y: (center - py) * kmPx, area: count, weight: sw });
      }
    }
    return comps;
  }
  function fitRadarTrack(points) {
    if (points.length < 4) return null;
    const t0 = points[0].time / 60, ts = points.map(p => p.time / 60 - t0), xs = points.map(p => p.x), ys = points.map(p => p.y);
    if (ts[ts.length - 1] - ts[0] < 25) return null;
    const mean = a => a.reduce((s, v) => s + v, 0) / a.length;
    const mt = mean(ts), mx = mean(xs), my = mean(ys);
    let den = 0, vxN = 0, vyN = 0;
    for (let i = 0; i < ts.length; i++) { const d = ts[i] - mt; den += d * d; vxN += d * (xs[i] - mx); vyN += d * (ys[i] - my); }
    if (!den) return null;
    const vx = vxN / den * 60, vy = vyN / den * 60; // km/h, x east, y north
    const speed = Math.hypot(vx, vy);
    const predX = ts.map(t => mx + vx / 60 * (t - mt)), predY = ts.map(t => my + vy / 60 * (t - mt));
    const ss = points.reduce((s, p, i) => s + (p.x - mx) ** 2 + (p.y - my) ** 2, 0);
    const err = points.reduce((s, p, i) => s + (p.x - predX[i]) ** 2 + (p.y - predY[i]) ** 2, 0);
    const r2 = ss > 0 ? clamp(1 - err / ss, 0, 1) : 0;
    const latest = points[points.length - 1], d2 = vx * vx + vy * vy;
    if (speed < 6 || speed > 130 || d2 < 1) return null;
    const closestH = -(latest.x * vx + latest.y * vy) / d2;
    const missKm = Math.hypot(latest.x + vx * closestH, latest.y + vy * closestH);
    const distanceKm = Math.hypot(latest.x, latest.y);
    const toward = latest.x * vx + latest.y * vy < 0;
    const etaMin = toward && closestH >= 0 ? Math.round(closestH * 60) : null;
    const bearing = (Math.atan2(vx, vy) * 180 / Math.PI + 360) % 360;
    const confidence = points.length >= 5 && r2 >= 0.62 ? 'alta' : points.length >= 4 && r2 >= 0.48 ? 'media' : 'baja';
    return { points, speedKmh: Math.round(speed), bearing: Math.round(bearing), distanceKm: Math.round(distanceKm),
      missKm: Math.round(missKm), etaMin, toward, approaching: toward && closestH >= 0 && missKm <= 25 && etaMin != null,
      r2: Math.round(r2 * 100) / 100, confidence, observedMin: Math.round(ts[ts.length - 1] - ts[0]),
      latestX: latest.x, latestY: latest.y, latestTime: latest.time };
  }
  g.trackRadarMotion = async function (loc, frames, host) {
    try {
      if (!loc || !Number.isFinite(+loc.lat) || !Number.isFinite(+loc.lon)) return null;
      const usable = (frames || []).filter(f => f && f.path && Number.isFinite(+f.time)).slice(-5);
      if (usable.length < 4) return { available: false, reason: 'No hay suficientes imágenes históricas de radar.' };
      const cacheKey = loc.lat.toFixed(3) + ',' + loc.lon.toFixed(3) + ':' + usable[usable.length - 1].time;
      const cached = radarTrackCache.get(cacheKey);
      if (cached && Date.now() - cached.at < 4 * 60000) return cached.value;
      const samples = await Promise.all(usable.map(async f => {
        const url = (host || 'https://tilecache.rainviewer.com').replace(/\/$/, '') + f.path + '/' + RADAR_SIZE + '/' + RADAR_Z + '/' + (+loc.lat).toFixed(4) + '/' + (+loc.lon).toFixed(4) + '/2/1_1.png';
        try {
          const image = await radarBitmap(url), comps = radarEchoComponents(image, +loc.lat);
          return { time: +f.time, comps };
        } catch (e) { return { time: +f.time, comps: [], error: (e && e.message) || 'error' }; }
      }));
      const lastSample = samples[samples.length - 1];
      if (!lastSample || !lastSample.comps.length) return { available: false, reason: 'El radar no muestra ecos analizables cerca de este punto o no hay cobertura. Esto no confirma ausencia de tormenta.' };
      const candidates = lastSample.comps.slice().sort((a, b) => Math.hypot(a.x, a.y) - Math.hypot(b.x, b.y)).slice(0, 5);
      const fits = [];
      for (const seed of candidates) {
        const reverse = [{ time: lastSample.time, x: seed.x, y: seed.y, area: seed.area }];
        let next = seed, nextTime = lastSample.time;
        for (let i = samples.length - 2; i >= 0; i--) {
          const s = samples[i]; if (!s.comps.length) continue;
          const dtMin = Math.max(1, (nextTime - s.time) / 60), maxJump = Math.min(140, 35 + dtMin * 0.16);
          let best = null, bd = Infinity;
          for (const c of s.comps) { const d = Math.hypot(c.x - next.x, c.y - next.y); if (d < bd) { bd = d; best = c; } }
          if (best && bd <= maxJump) { reverse.push({ time: s.time, x: best.x, y: best.y, area: best.area }); next = best; nextTime = s.time; }
        }
        const points = reverse.reverse(), fit = fitRadarTrack(points);
        if (fit) fits.push(fit);
      }
      if (!fits.length) return { available: true, detected: true, reason: 'Hay ecos de precipitación, pero todavía no hay suficientes imágenes coherentes para calcular una trayectoria confiable.', latest: candidates[0] || null };
      fits.sort((a, b) => {
        if (a.approaching !== b.approaching) return a.approaching ? -1 : 1;
        if (a.approaching && b.approaching) return (a.missKm - b.missKm) || ((a.etaMin || 9999) - (b.etaMin || 9999));
        return a.distanceKm - b.distanceKm;
      });
      const fit = fits[0];
      fit.available = true; fit.detected = true;
      fit.cellLat = +loc.lat + fit.latestY / 111.32;
      fit.cellLon = +loc.lon + fit.latestX / (111.32 * Math.cos(+loc.lat * Math.PI / 180));
      fit.source = 'RainViewer'; fit.sampleCount = fit.points.length;
      const value = fit;
      radarTrackCache.set(cacheKey, { at: Date.now(), value });
      while (radarTrackCache.size > 40) radarTrackCache.delete(radarTrackCache.keys().next().value);
      return value;
    } catch (e) { return { available: false, reason: 'No se pudo analizar el radar: ' + ((e && e.message) || 'error') }; }
  };

  // ---- Alertas oficiales SMN (CAP): la geometría del aviso debe cubrir el punto ----
  // Se usa el feed público CAP del SMN. Si la fuente no responde o no se puede verificar
  // el polígono, no se inventa una alerta ni se etiqueta viento fuerte como Zonda.
  const CAP_FEED = 'https://ssl.smn.gob.ar/CAP/AR.php';
  let capCache = { at: 0, items: [] }, capPromise = null;
  g.officialAlertsStatus = 'SMN: todavía sin consultar';
  g.officialAlertsState = 'checking';
  g.officialAlertsCheckedAt = 0;
  const xmlText = (s) => String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/\s+/g, ' ').trim();
  function capTags(xml, name) {
    const re = new RegExp('<(?:[\\w.-]+:)?' + name + '(?:\\s[^>]*)?>([\\s\\S]*?)<\\/(?:[\\w.-]+:)?' + name + '\\s*>', 'gi');
    const out = []; let m; while ((m = re.exec(xml))) out.push(xmlText(m[1])); return out;
  }
  function pointInPoly(lat, lon, pts) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[i], b = pts[j];
      if (((a[1] > lon) !== (b[1] > lon)) && (lat < (b[0] - a[0]) * (lon - a[1]) / ((b[1] - a[1]) || 1e-12) + a[0])) inside = !inside;
    }
    return inside;
  }
  function capCovers(xml, loc) {
    let checked = false;
    for (const raw of capTags(xml, 'polygon')) {
      const pts = raw.split(/\s+/).map(x => x.split(',').map(Number)).filter(x => x.length >= 2 && Number.isFinite(x[0]) && Number.isFinite(x[1]));
      if (pts.length >= 3) { checked = true; if (pointInPoly(loc.lat, loc.lon, pts)) return true; }
    }
    for (const raw of capTags(xml, 'circle')) {
      const m = raw.match(/(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)/);
      if (m) {
        checked = true;
        const a = Number(m[1]), b = Number(m[2]), r = Number(m[3]);
        const dx = (loc.lon - b) * 111.32 * Math.cos(loc.lat * Math.PI / 180), dy = (loc.lat - a) * 111.32;
        if (Math.hypot(dx, dy) <= r) return true;
      }
    }
    return false; // sin polígono/círculo verificable: no se dispara
  }
  async function capFetch(url, timeoutMs) {
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), timeoutMs || 7000);
    try { return await fetch(url, { cache: 'no-store', signal: controller.signal }); }
    finally { clearTimeout(timer); }
  }
  async function loadCapItems() {
    if (Date.now() - capCache.at < 10 * 60000) return capCache.items;
    if (capPromise) return capPromise;
    capPromise = (async () => {
      const r = await capFetch(CAP_FEED, 7000);
      if (!r.ok) throw new Error('SMN CAP HTTP ' + r.status);
      const body = await r.text();
      const links = [];
      if (/<(?:[\w.-]+:)?alert[\s>]/i.test(body)) links.push({ url: CAP_FEED, title: 'Aviso SMN' });
      const re = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
      let m;
      while ((m = re.exec(body)) && links.length < 100) {
        const href = m[1], label = xmlText(m[2]);
        if (!/(\.xml|cap|alert|zonda|viento|torment|lluv|granizo|helad|nieve)/i.test(href + ' ' + label)) continue;
        links.push({ url: new URL(href, CAP_FEED).href, title: label || href });
      }
      // Algunos despliegues entregan RSS o Atom en vez de una página HTML.
      const lr = /<link\b[^>]*(?:href=["']([^"']+)["'][^>]*>|>(https?:[^<]+)<\/link>)/gi;
      while ((m = lr.exec(body)) && links.length < 100) {
        const href = m[1] || xmlText(m[2]) || '';
        if (!/https?:/i.test(href) || !/(\.xml|cap|alert|zonda|viento|torment|lluv|granizo|helad|nieve)/i.test(href)) continue;
        links.push({ url: new URL(href, CAP_FEED).href, title: href });
      }
      if (!links.length && /<(?:item|entry)\b/i.test(body)) {
        throw new Error('El SMN publicó elementos, pero no se pudieron resolver sus avisos CAP.');
      }
      const unique = [...new Map(links.map(x => [x.url, x])).values()].slice(0, 80);
      if (!links.length && !/<(?:rss|feed)\b/i.test(body) && !/<(?:[\w.-]+:)?alert[\s>]/i.test(body)) {
        throw new Error('El SMN respondió, pero el formato no permite confirmar si hay avisos vigentes.');
      }
      const settled = [], cancelled = new Set(); let cursor = 0;
      const workers = Array.from({ length: 8 }, async () => {
        while (cursor < unique.length) {
          const x = unique[cursor++];
          try {
            const q = await capFetch(x.url, 7000); if (!q.ok) throw new Error('CAP ' + q.status);
            const xml = await q.text();
            const event = capTags(xml, 'event')[0] || x.title || '';
            const headline = capTags(xml, 'headline')[0] || event;
            const desc = capTags(xml, 'description')[0] || '';
            const area = capTags(xml, 'areaDesc').join(' · ');
            const expires = Date.parse(capTags(xml, 'expires')[0] || '');
            const effective = Date.parse(capTags(xml, 'effective')[0] || capTags(xml, 'onset')[0] || '');
            const status = (capTags(xml, 'status')[0] || '').toLowerCase();
            const msgType = (capTags(xml, 'msgType')[0] || '').toLowerCase();
            const identifier = capTags(xml, 'identifier')[0] || '';
            if (msgType === 'cancel') {
              capTags(xml, 'references').forEach(raw => raw.split(/\s+/).forEach(ref => {
                const parts = ref.split(','); if (parts.length >= 2 && parts[1]) cancelled.add(parts[1]);
              }));
              continue;
            }
            // No convertir pruebas, ejercicios, cancelaciones ni avisos ya vencidos en alertas vigentes.
            if (status !== 'actual' || !['alert', 'update'].includes(msgType)) continue;
            if (expires && expires < Date.now()) continue;
            if (!capTags(xml, 'polygon').length && !capTags(xml, 'circle').length) continue;
            settled.push({ xml, event, headline, desc, area, expires, effective, identifier, url: x.url,
              sent: capTags(xml, 'sent')[0] || '', severity: capTags(xml, 'severity')[0] || '' });
          } catch (e) { /* Un CAP individual no invalida los demás avisos. */ }
        }
      });
      await Promise.all(workers);
      const items = settled.filter(a => !cancelled.has(a.identifier));
      capCache = { at: Date.now(), items };
      g.officialAlertsState = 'ok';
      g.officialAlertsCheckedAt = Date.now();
      return items;
    })().finally(() => { capPromise = null; });
    return capPromise;
  }
  g.fetchOfficialAlertsForPoint = async function (loc) {
    try {
      const items = await loadCapItems(), out = [];
      items.forEach(a => {
        if (!capCovers(a.xml, loc)) return;
        const label = (a.event + ' ' + a.headline + ' ' + a.desc).toLowerCase();
        let type = null;
        if (/zonda/.test(label)) type = 'zonda';
        else if (/helada|temperaturas? m[ií]nimas? extremas/.test(label)) type = 'frost';
        else if (/granizo|tormenta severa/.test(label)) type = 'hail';
        else if (/tormenta|lluvia intensa/.test(label)) type = 'stormStrong';
        else if (/viento/.test(label)) type = 'wind';
        if (!type) return;
        const sev = (a.severity || '').toLowerCase();
        const level = /extreme|severe/.test(sev) ? 3 : /moderate/.test(sev) ? 2 : 1;
        out.push({ type, level, title: a.headline || g.TYPES[type].label, place: loc.name,
          key: 'smn:' + a.url, detail: 'Aviso oficial del SMN para el área: ' + (a.area || 'área indicada en el aviso') + '. ' +
            (a.desc || '') + (a.effective ? ' Comienza: ' + new Date(a.effective).toLocaleString('es-AR') + '.' : '') +
            (a.sent ? ' Publicado: ' + new Date(a.sent).toLocaleString('es-AR') + '.' : '') +
            (a.expires ? ' Válido hasta: ' + new Date(a.expires).toLocaleString('es-AR') + '.' : '') + ' Fuente: SMN.', source: a.url });
      });
      g.officialAlertsState = 'ok';
      g.officialAlertsCheckedAt = Date.now();
      g.officialAlertsStatus = out.length
        ? 'SMN: ' + out.length + ' aviso(s) oficial(es) aplicable(s) · revisado ' + new Date(g.officialAlertsCheckedAt).toLocaleTimeString('es-AR', {hour:'2-digit',minute:'2-digit'})
        : 'SMN: sin alertas vigentes para este punto · revisado ' + new Date(g.officialAlertsCheckedAt).toLocaleTimeString('es-AR', {hour:'2-digit',minute:'2-digit'});
      return out;
    } catch (e) {
      g.officialAlertsState = 'unavailable';
      g.officialAlertsCheckedAt = Date.now();
      g.officialAlertsStatus = 'SMN: fuente no disponible o aviso no verificable';
      return [];
    }
  };

  // ---- Sismos (USGS: con CORS, sirve desde navegador y service worker) ----
  g.fetchUSGS = async function (loc, cfg) {
    const start = new Date(Date.now() - 3 * 3600e3).toISOString();
    const u = 'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=time&starttime=' + start +
      '&latitude=' + loc.lat + '&longitude=' + loc.lon + '&maxradiuskm=' + cfg.quakeKm + '&minmagnitude=' + cfg.quakeMag;
    const j = await (await fetch(u)).json();
    return (j.features || []).map(f => ({
      id: f.id, lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0], depth: f.geometry.coordinates[2],
      mag: f.properties.mag, place: f.properties.place, time: f.properties.time
    }));
  };
  g.quakeEvents = function (list, loc, place) {
    if (!list || !list.length) return [];
    const q = list.reduce((a, b) => (b.mag > a.mag ? b : a));
    const d = Math.round(Math.hypot((q.lat - loc.lat) * 111, (q.lon - loc.lon) * 111 * Math.cos(loc.lat * Math.PI / 180)));
    return [{
      type: 'quake', level: q.mag >= 5 ? 3 : q.mag >= 4 ? 2 : 1, key: q.id, place: place,
      title: 'Sismo M' + Number(q.mag).toFixed(1),
      detail: (q.place || 'Región cercana') + ' · a ' + d + ' km de ' + (place || 'tu ubicación') + ' · prof. ' + Math.round(q.depth) + ' km.',
      lat: q.lat, lon: q.lon
    }];
  };

  // ---- Notificaciones ----
  g.evKey = e => (e.type === 'quake' ? 'quake' + e.key : e.type + (e.place ? '@' + e.place : ''));

  g.shouldNotify = function (map, e, cfg, now) {
    if (!cfg.notify[e.type]) return false;
    const k = g.evKey(e), p = map[k];
    if (p) {
      if (e.type === 'quake') return false;
      if (now - p.t < cfg.repeatMin * 60000 && e.level <= p.level) return false;
    }
    map[k] = { t: now, level: e.level };
    return true;
  };
  g.pruneNotified = function (map, events) {
    const present = new Set(events.map(g.evKey)), now = Date.now();
    Object.keys(map).forEach(k => {
      if (k.indexOf('quake') === 0) { if (now - map[k].t > 24 * 3600e3) delete map[k]; }
      else if (!present.has(k)) delete map[k];
    });
  };

  // Título + opciones de notificación (con acciones: llamar al 911 / qué hacer)
  g.notifOptions = function (e, cfg) {
    const t = g.TYPES[e.type];
    return {
      title: t.icon + ' ' + e.title + (e.place ? ' · ' + e.place : ''),
      opts: {
        body: e.detail + '\n👉 ' + g.TIPS[e.type],
        tag: g.evKey(e), renotify: true, icon: 'icon-192.png', badge: 'icon-192.png',
        vibrate: cfg.vibrate ? [300, 150, 300, 150, 400] : [],
        requireInteraction: e.level >= 2,
        actions: [{ action: 'call', title: '📞 Llamar 911' }, { action: 'open', title: 'Qué hacer' }],
        data: { type: e.type }
      }
    };
  };
})(typeof self !== 'undefined' ? self : this);
