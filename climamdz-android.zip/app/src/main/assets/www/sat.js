/* Capas de satélite (NASA GIBS, GOES-East), comparación con el infrarrojo, movimiento y seguimiento de tormentas.
   Como no se puede confirmar de antemano en qué formato/nivel publica GIBS cada capa, al activarla se prueban las
   variantes con una tesela de prueba y se recuerda la que anda. */
(function (g) {
  'use strict';
  const $ = id => document.getElementById(id);
  const GIBS = 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/';
  const DEF = {
    ir:  { label: 'Infrarrojo', id: 'GOES-East_ABI_Band13_Clean_Infrared', cands: [['png', 6]], op: .65 },
    geo: { label: 'Color real', id: 'GOES-East_ABI_GeoColor', cands: [['jpeg', 7], ['png', 7], ['jpeg', 6], ['png', 6], ['jpeg', 8], ['png', 8]], op: .92 },
    vis: { label: 'Visible', id: 'GOES-East_ABI_Band2_Red_Visible_1km', cands: [['jpeg', 7], ['png', 7], ['jpeg', 8], ['png', 8], ['jpeg', 6], ['png', 6]], op: .92 },
    air: { label: 'Masa de aire', id: 'GOES-East_ABI_Air_Mass', cands: [['png', 6], ['jpeg', 6], ['png', 7], ['jpeg', 7]], op: .85 }
  };
  const LSget = k => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } };
  const LSset = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

  function imgOk(url) {
    return new Promise(res => {
      const im = new Image(); let done = false;
      const end = v => { if (!done) { done = true; res(v); } };
      im.onload = () => end(true); im.onerror = () => end(false); setTimeout(() => end(false), 7000);
      im.src = url;
    });
  }
  const variant = {};   // key -> {ext,lvl} | null
  async function probe(key) {
    if (key === 'ir') return { ext: 'png', lvl: 6 };
    if (variant[key] !== undefined) return variant[key];
    const saved = LSget('satv:' + key);
    if (saved) return (variant[key] = saved);
    for (const [ext, lvl] of DEF[key].cands) {
      if (await imgOk(GIBS + DEF[key].id + '/default/default/GoogleMapsCompatible_Level' + lvl + '/3/4/2.' + ext)) {
        variant[key] = { ext, lvl }; LSset('satv:' + key, variant[key]); return variant[key];
      }
    }
    return (variant[key] = null);
  }
  function make(key, v, time, opacity, z) {
    return L.tileLayer(GIBS + DEF[key].id + '/default/' + (time || 'default') + '/GoogleMapsCompatible_Level' + v.lvl + '/{z}/{y}/{x}.' + v.ext,
      { opacity: opacity == null ? DEF[key].op : opacity, maxNativeZoom: v.lvl, maxZoom: 18, zIndex: z || 4, attribution: 'NASA GIBS / GOES' });
  }
  async function radarLayer() {
    const r = await (await fetch('https://api.rainviewer.com/public/weather-maps.json')).json();
    const past = (r.radar && r.radar.past) || []; if (!past.length) throw new Error('sin radar');
    return L.tileLayer((r.host || 'https://tilecache.rainviewer.com') + past[past.length - 1].path + '/256/{z}/{x}/{y}/2/1_1.png', { opacity: .8, maxNativeZoom: 7, maxZoom: 18, zIndex: 6, attribution: 'RainViewer' });
  }

  /* ---------- estado y aplicación ---------- */
  let A = 'ir', B = '', anim = false, trk = true, layA = null, layB = null, frames = [], animT = null, token = 0, lastAp = null, lastP = null;
  const trkLayer = L.layerGroup().addTo(map);
  const extra = () => { [layA, layB].concat(frames).forEach(l => { if (l && l !== irL && map.hasLayer(l)) map.removeLayer(l); }); layA = layB = null; frames = []; clearInterval(animT); animT = null; };
  const info = t => { $('satInfo').textContent = t || ''; };
  const hm = t => new Date(t).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });

  function clip() {
    const dv = $('satDiv');
    if (!B || !layA || !layB || !layA.getContainer || !layA.getContainer() || !layB.getContainer()) { dv.style.display = 'none'; [layA, layB].forEach(l => { if (l && l.getContainer && l.getContainer()) l.getContainer().style.clip = ''; }); return; }
    const sz = map.getSize(), x = sz.x * (+$('satSl').value) / 100;
    const nw = map.containerPointToLayerPoint([0, 0]), se = map.containerPointToLayerPoint(sz), cx = map.containerPointToLayerPoint([x, 0]).x;
    layA.getContainer().style.clip = 'rect(' + [nw.y, cx, se.y, nw.x].join('px,') + 'px)';
    layB.getContainer().style.clip = 'rect(' + [nw.y, se.x, se.y, cx].join('px,') + 'px)';
    dv.style.display = 'block'; dv.style.left = x + 'px';
  }

  async function apply() {
    const my = ++token;
    extra();
    if (A === 'ir') { irOn = true; $('clouds').classList.add('on'); if (!map.hasLayer(irL)) irL.addTo(map); $('legend').style.display = 'block'; }
    else { if (map.hasLayer(irL)) map.removeLayer(irL); irOn = false; $('clouds').classList.remove('on'); $('legend').style.display = 'none'; }
    $('satSl').style.display = B ? 'block' : 'none';
    info('');
    try {
      if (anim) {
        const fr = await Approach.latestFrame(pos.lat, pos.lon);
        if (!fr || !fr.explicit) { info('El satélite no entregó imágenes con hora: no se puede animar ahora.'); anim = false; $('satAnim').checked = false; return apply(); }
        const v = await probe(A); if (my !== token) return;
        if (!v) { info('La capa ' + DEF[A].label + ' no está disponible ahora.'); return; }
        const ts = []; for (let k = 5; k >= 0; k--) ts.push(fr.t - k * 600000);
        if (map.hasLayer(irL)) map.removeLayer(irL);
        frames = ts.map(t => make(A, v, new Date(t).toISOString().slice(0, 19) + 'Z', 0, 4).addTo(map));
        let i = 0; const show = () => { frames.forEach((l, j) => l.setOpacity(j === i ? DEF[A].op : 0)); info('▶ Imagen de las ' + hm(ts[i]) + ' (' + (i + 1) + '/' + ts.length + ') · cada cuadro = 10 min'); i = (i + 1) % frames.length; };
        show(); animT = setInterval(show, 800);
        return;
      }
      if (A !== 'ir') {
        const v = await probe(A); if (my !== token) return;
        if (!v) { info('La capa ' + DEF[A].label + ' no está disponible ahora. Probá con otra.'); return; }
        layA = make(A, v, null, null, 4).addTo(map);
      } else layA = irL;
      if (B) {
        let lb;
        if (B === 'radar') lb = await radarLayer();
        else { const v = await probe(B); if (my !== token) return; if (!v) { info('La capa ' + DEF[B].label + ' no está disponible ahora.'); return; } lb = make(B, v, null, null, 5); }
        if (my !== token) return;
        layB = lb.addTo(map); if (layA === irL) irL.setOpacity(.9);
        setTimeout(clip, 60); layA.once('load', clip); layB.once('load', clip);
        info('◀ ' + DEF[A].label + ' · ' + (B === 'radar' ? 'Radar de lluvia' : DEF[B].label) + ' ▶  (deslizá la barra para comparar)');
      } else if (layA === irL) irL.setOpacity(DEF.ir.op);
    } catch (e) { info('No se pudo cargar la imagen (sin conexión).'); }
    clip();
  }

  /* ---------- seguimiento de tormentas sobre el mapa ---------- */
  const COL = { hail: '#7b1fa2', stormStrong: '#d32f2f', stormWeak: '#f9a825' };
  g.showTracks = function (ap, P) {
    lastAp = ap; lastP = P; trkLayer.clearLayers();
    if (!trk) return;
    if (!ap || ap.status === 'sin-imagenes' && !(ap.tracks && ap.tracks.length)) { if (!anim && !B) info('Sin imágenes del satélite en este momento: el seguimiento usa solo el viento en altura.'); return; }
    if (ap.status === 'sin-celdas') { if (!anim && !B) info('🛰 Sin tormentas en 150 km a la redonda' + (ap.frame ? ' (imagen de las ' + hm(ap.frame.t) + ')' : '') + '.'); return; }
    (ap.tracks || []).forEach(t => {
      const c = COL[t.type] || '#607d8b', live = t.threat || t.pending;
      const ci = L.circle([t.lat, t.lon], { radius: t.r * 1000, color: c, weight: live ? 3 : 1.5, dashArray: live ? null : '4 6', fillOpacity: live ? .25 : .08 }).addTo(trkLayer);
      const txt = (TYPES[t.type] ? TYPES[t.type].icon + ' ' : '') + (t.tmin <= -65 ? 'muy fuerte' : t.tmin <= -55 ? 'fuerte' : 'moderada') + ' · ' + Math.round(t.d) + ' km · ' +
        (t.hit ? (t.etaMin === 0 ? 'sobre la zona' : 'llega en ~' + t.etaMin + ' min') : 'no se dirige a vos');
      ci.bindTooltip(txt, { permanent: live, direction: 'top', className: 'trk' + (t.threat ? ' hot' : '') });
    });
    const v = ap.vec;
    if (v && v.ok) {
      const end = dest(P.lat, P.lon, v.dir, Math.min(90, v.spd * .75));
      L.polyline([[P.lat, P.lon], end], { color: '#00e5ff', weight: 3, dashArray: '2 6' }).addTo(trkLayer);
      L.marker(end, { icon: L.divIcon({ className: 'trkArrow', html: '<span>➤ ' + Math.round(v.spd) + ' km/h</span>', iconSize: [90, 18] }) }).addTo(trkLayer);
    }
    if (!anim && !B) {
      const n = (ap.tracks || []).length;
      info('🛰 Imagen de las ' + (ap.frame ? hm(ap.frame.t) + ' (hace ' + ap.frame.ageMin + ' min; las celdas se adelantaron a "ahora")' : '—') + ' · ' + n + ' celda(s)' +
        (v ? ' · rumbo ' + (v.ok ? bearingName(v.dir) + ' ' + Math.round(v.spd) + ' km/h (' + v.src + ')' : v.src) : ''));
    }
  };

  /* ---------- viento en flechas (Open-Meteo, grilla 5x5 sobre lo que se ve en el mapa) ---------- */
  const windL = L.layerGroup().addTo(map); let windOn = false, windT = 0;
  async function drawWind() {
    windL.clearLayers(); if (!windOn) return;
    const b = map.getBounds(), n = 5, la = [], lo = [];
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { la.push((b.getSouth() + (b.getNorth() - b.getSouth()) * (i + .5) / n).toFixed(3)); lo.push((b.getWest() + (b.getEast() - b.getWest()) * (j + .5) / n).toFixed(3)); }
    const my = ++windT;
    try {
      const r = await fetch('https://api.open-meteo.com/v1/forecast?latitude=' + la.join(',') + '&longitude=' + lo.join(',') + '&current=wind_speed_10m,wind_direction_10m,wind_gusts_10m&wind_speed_unit=kmh');
      let d = await r.json(); if (!Array.isArray(d)) d = [d]; if (my !== windT) return;
      d.forEach((x, k) => {
        const c = x && x.current; if (!c || c.wind_speed_10m == null) return;
        const sp = Math.round(c.wind_speed_10m), gu = Math.round(c.wind_gusts_10m || 0);
        const col = gu >= 60 ? '#ff5252' : gu >= 40 ? '#ffb300' : '#fff';
        L.marker([+la[k], +lo[k]], { interactive: false, icon: L.divIcon({ className: 'wArr', iconSize: [34, 30], html: '<div style="transform:rotate(' + ((c.wind_direction_10m + 90) % 360) + 'deg);color:' + col + '">➤</div><small style="color:' + col + '">' + sp + '</small>' }) }).addTo(windL);
      });
    } catch (e) { info('No se pudo cargar el viento (sin conexión).'); }
  }

  function init() {
    $('satWind').onchange = () => { windOn = $('satWind').checked; drawWind(); };
    map.on('moveend', () => { if (windOn) { clearTimeout(g._wt); g._wt = setTimeout(drawWind, 700); } });
    $('satBtn').onclick = () => { const p = $('satPanel'); p.style.display = p.style.display === 'block' ? 'none' : 'block'; };
    $('satX').onclick = () => { $('satPanel').style.display = 'none'; };
    $('satA').onchange = () => { A = $('satA').value; if (B === A) { B = ''; $('satB').value = ''; } apply(); };
    $('satB').onchange = () => { B = $('satB').value; if (B) { anim = false; $('satAnim').checked = false; } if (B === A) { B = ''; $('satB').value = ''; } apply(); };
    $('satAnim').onchange = () => { anim = $('satAnim').checked; if (anim) { B = ''; $('satB').value = ''; } apply(); };
    $('satTrk').onchange = () => { trk = $('satTrk').checked; if (!trk) { trkLayer.clearLayers(); info(''); } else if (lastAp) g.showTracks(lastAp, lastP); };
    $('satSl').oninput = clip;
    map.on('move zoom viewreset resize', clip);
    // el botón "☁ Nubes IR" de la barra sigue funcionando: si lo apagan, la comparación con IR se desactiva
    $('clouds').addEventListener('click', () => { if (A === 'ir' && B && !irOn) { B = ''; $('satB').value = ''; apply(); } });
  }
  init();
  g._sat = { apply, probe, DEF };
})(window);
