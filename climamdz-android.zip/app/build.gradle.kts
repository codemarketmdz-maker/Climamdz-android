plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ar.mdz.clima"
    compileSdk = 34

    defaultConfig {
        applicationId = "ar.mdz.clima"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "1.10"
    }

    signingConfigs {
        create("clima") {
            storeFile = file("../clima.keystore")
            storePassword = "climamdz123"
            keyAlias = "clima"
            keyPassword = "climamdz123"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("clima")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
